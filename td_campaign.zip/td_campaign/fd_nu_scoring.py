import psycopg2
import shutil
import pandas as pd
import redshift_connector    
from datetime import timedelta
import io
import boto3
import datetime as dt 

from datetime import datetime
import joblib
import numpy as np
import tempfile
import sklearn




# from s3fs.core import S3FileSystem
from datetime import timedelta
pd.set_option('display.float_format', lambda x: '%.3f' % x)

from common_utils.helper import RedshiftUser

session = boto3.Session()

s3 = session.client('s3')

today=dt.date.today()

if today.day <15 :
    mnthid=str(today.year)+"-"+str(today.month)
    last_month = today.replace(day=1) + dt.timedelta(days=-10)

    ref_d1=dt.date.today().replace(day=1) - timedelta(days=1)
    last_mnth=str(last_month.year)+"-"+str(last_month.month)

elif today.day>=15:
    last = today.replace(day=28)
    last_month = last + dt.timedelta(days=10)
    mnthid=str(last_month.year)+"-"+str(last_month.month)
    ref_d1=dt.date.today().replace(day=1) - timedelta(days=45)
    last_mnth=str(last.year)+"-"+str(last.month)

    
ref_d2=ref_d1.replace(day=1) - timedelta(days=1)
ref_d3=ref_d2.replace(day=1) - timedelta(days=1)
ref_d4=ref_d3.replace(day=1) - timedelta(days=1)
ref_d5=ref_d4.replace(day=1) - timedelta(days=1)
ref_d6=ref_d5.replace(day=1) - timedelta(days=1)

login=pd.to_datetime(ref_d4).strftime("%Y-%m-%d")

ref_m1=ref_d1.year*100+ref_d1.month
ref_m2=ref_d2.year*100+ref_d2.month
ref_m3=ref_d3.year*100+ref_d3.month
ref_m4=ref_d4.year*100+ref_d4.month
ref_m5=ref_d5.year*100+ref_d5.month
ref_m6=ref_d6.year*100+ref_d6.month


redshift_username = 'dsg_kmbl227932_anashwara'
redshift_password  = RedshiftUser(redshift_username).get_password().decode("utf-8")

conn = redshift_connector.connect(
     host="prod-de-redshift-cluster.cgjabuq7ccxq.ap-south-1.redshift.amazonaws.com",
     database="prod_db",
     port=5439,
     user=redshift_username,
     password=redshift_password)


connection: redshift_connector.Cursor = conn.cursor()


# #811 brand
sql = connection.execute("""
   with

saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A' 
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
),

crns as (
select distinct  a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn

),


  avg_amb as (
    select
      crn,
      case
    
        when m9_cr_amb > 0 then 1
        else 0
      end + case
        when m2_cr_amb > 0 then 1
        else 0
      end + case
        when m3_cr_amb > 0 then 1
        else 0
      end + case
        when m4_cr_amb > 0 then 1
        else 0
      end + case
        when m5_cr_amb > 0 then 1
        else 0
      end + case
        when m6_cr_amb > 0 then 1
        else 0
      end + case
        when m7_cr_amb > 0 then 1
        else 0
      end + case
        when m8_cr_amb > 0 then 1
        else 0
      end as cnt,
    case when cnt>0 then   (
        coalesce(m9_cr_amb, 0) + coalesce(m2_cr_amb, 0) + coalesce(m3_cr_amb, 0) + coalesce(m4_cr_amb, 0) 
        + coalesce(m5_cr_amb, 0) + coalesce(m6_cr_amb, 0) + coalesce(m7_cr_amb, 0) + coalesce(m8_cr_amb, 0) 
       
      ) / cnt else 0 end  as avg_amb
    from
      prod_db.dsg_portfolio.mom_amb
    where
      yr_id = 2024
      and prodct_type = 'SBA'
      and cnt > 0
  ),
  crdr as 
  (select crn,
   sum( case when month_year ={ref_m1} then cr_cnt else 0 end) as m1_cnt,

 sum( case when month_year ={ref_m2} then cr_cnt else 0 end) as m2_cnt,
  sum( case when month_year ={ref_m3} then cr_cnt else 0 end) as m3_cnt,
 sum( case when month_year ={ref_m4} then cr_cnt else 0 end) as m4_cnt,
 
 sum( case when month_year ={ref_m5} then cr_cnt else 0 end) as m5_cnt

  from prod_db.dsg_portfolio.mom_tran_crdr 
  
  group by crn 
  having ((m1_cnt+m2_cnt+m3_cnt+m4_cnt+m5_cnt)>0)
  ),
  target_1 as (
    select
      a.crn,
      a.accnt_opn_date,open_schme_code,current_schme_code,
      
      case when open_schme_code in ('LSJIFL','LSJIFW','SJIFW','SJIFL') then  fkyc_date else accnt_opn_date end as fkyc_date
          
    from   
      prod_db.dsg_services.funding_file_monthly a
      join avg_amb  b on a.crn = b.crn
      join crns c 
      on a.crn=c.crn
      
    where
      cast(fkyc_date as date) >= '2018-03-01'
      and cast(fkyc_date as date) <= '{ref_d3}'
and current_schme_code in ('LSJIFN','LSDIGI','SJIFN','SDIGI')   
and cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
and avg_amb>100
and accnt_cls_flag='N'
and accnt_status ='A'
and report_month =(select max(report_month) from dsg_services.funding_file_monthly)

and a.crn not in (
        select
          crn
        from
prod_db.dsg_portfolio.rel_td_account_details
        where
          prodct_code not like '%FF%'
          and prodct_code not like '%RD%'
            )
  )
  
select distinct a.crn, accnt_opn_date,open_schme_code,current_schme_code, fkyc_date
from
  target_1 a 
  join crdr b 
  on a.crn=b.crn
""".format(ref_d3=ref_d3,ref_m1=ref_m1,ref_m2=ref_m2,ref_m3=ref_m3,ref_m4=ref_m4,ref_m5=ref_m5))
scoring_base = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/fd_nu_scoring_live/scoring.csv'

buffer = io.BytesIO()
scoring_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/fd_scoring/month={mnthid}/scoring_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
scoring_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




########### create table 

host = "prod-de-redshift-cluster.cgjabuq7ccxq.ap-south-1.redshift.amazonaws.com"
port = "5439"
db = "mydb"
redshift_username = 'dsg_kmbl227932_anashwara'
redshift_password  = RedshiftUser(redshift_username).get_password().decode("utf-8")

# username = "dsg_kmbl327599_arion"
# password = "n#MWf6LY" # password for redshift
uri = f"postgresql://{redshift_username}:{redshift_password}@{host}:{port}/{db}"
 
 
con=psycopg2.connect(uri)
con.autocommit = True
cursor = con.cursor()
 
create_query='CREATE TABLE if not exists mydb.dsg_portfolio.fd_nu_scoring(crn varchar,accnt_opn_date date,open_schme_code varchar,current_schme_code varchar,fkyc_date date);'
copy_query="""
COPY mydb.dsg_portfolio.fd_nu_scoring from
's3://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/fd_scoring_live/scoring.csv'
iam_role 'arn:aws:iam::718378052708:role/service-role/AmazonRedshift-CommandsAccessRole-20240513T161101'
CSV IGNOREHEADER 1"""
cursor.execute(create_query)
cursor.execute(copy_query)

con.close()



###############  amb

sql = connection.execute("""
 with pre_mnth as (
 SELECT crn,
DATEADD(month, -1, current_date) as m1,
DATEADD(month, -2, current_date) as m2,
DATEADD(month, -3, current_date) as m3,
DATEADD(month, -4, current_date) as m4,
DATEADD(month, -5, current_date) as m5,
DATEADD(month, -6, current_date) as m6,
(( extract(year from m1 ) *100 )+extract(month from  m1)) as my1,
(( extract(year from m2 ) *100 )+extract(month from  m2)) as my2,
(( extract(year from m3 ) *100 )+extract(month from  m3)) as my3,
(( extract(year from m4 ) *100 )+extract(month from  m4)) as my4,
(( extract(year from m5 ) *100 )+extract(month from  m5)) as my5,
(( extract(year from m6 ) *100 )+extract(month from  m6)) as my6

from mydb.dsg_portfolio.fd_nu_scoring 
)

select a.crn,
sum(case when mnth_year=my1 then amb else null end ) as amb_1,
sum(case when mnth_year=my2 then amb else null end ) as amb_2,
sum(case when mnth_year=my3 then amb else null end ) as amb_3,
sum(case when mnth_year=my4 then amb else null end ) as amb_4,
sum(case when mnth_year=my5 then amb else null end ) as amb_5,
sum(case when mnth_year=my6 then amb else null end ) as amb_6


from pre_mnth a 
left join prod_db.dsg_portfolio.mom_amb_tall b 
on a.crn=b.crn
and prodct_type='SBA'
group by a.crn

""")
amb = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/amb/month={mnthid}/amb_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
amb.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




######### tran

sql = connection.execute("""
  with pre_mnth as (
 SELECT crn,
DATEADD(month, -1, current_date::date) as m1,
DATEADD(month, -2, current_date::date) as m2,
DATEADD(month, -3, current_date::date) as m3,
DATEADD(month, -4, current_date::date) as m4,
DATEADD(month, -5, current_date::date) as m5,
DATEADD(month, -6, current_date::date) as m6,
(( extract(year from m1 ) *100 )+extract(month from  m1)) as my1,
(( extract(year from m2 ) *100 )+extract(month from  m2)) as my2,
(( extract(year from m3 ) *100 )+extract(month from  m3)) as my3,
(( extract(year from m4 ) *100 )+extract(month from  m4)) as my4,
(( extract(year from m5 ) *100 )+extract(month from  m5)) as my5,
(( extract(year from m6 ) *100 )+extract(month from  m6)) as my6

from mydb.dsg_portfolio.fd_nu_scoring  
)
select distinct
a.crn,
sum(case when monthid=my1 then cr_cnt else null end ) as cr_cnt_1,
sum(case when monthid=my2 then cr_cnt else null end ) as cr_cnt_2,
sum(case when monthid=my3 then cr_cnt else null end ) as cr_cnt_3,
sum(case when monthid=my4 then cr_cnt else null end ) as cr_cnt_4,
sum(case when monthid=my5 then cr_cnt else null end ) as cr_cnt_5,
sum(case when monthid=my6 then cr_cnt else null end ) as cr_cnt_6,

sum(case when monthid=my1 then cr_amt else null end ) as cr_amt_1,
sum(case when monthid=my2 then cr_amt else null end ) as cr_amt_2,
sum(case when monthid=my3 then cr_amt else null end ) as cr_amt_3,
sum(case when monthid=my4 then cr_amt else null end ) as cr_amt_4,
sum(case when monthid=my5 then cr_amt else null end ) as cr_amt_5,
sum(case when monthid=my6 then cr_amt else null end ) as cr_amt_6,

sum(case when monthid=my1 then dr_cnt else null end ) as dr_cnt_1,
sum(case when monthid=my2 then dr_cnt else null end ) as dr_cnt_2,
sum(case when monthid=my3 then dr_cnt else null end ) as dr_cnt_3,
sum(case when monthid=my4 then dr_cnt else null end ) as dr_cnt_4,
sum(case when monthid=my5 then dr_cnt else null end ) as dr_cnt_5,
sum(case when monthid=my6 then dr_cnt else null end ) as dr_cnt_6,

sum(case when monthid=my1 then dr_amt else null end ) as dr_amt_1,
sum(case when monthid=my2 then dr_amt else null end ) as dr_amt_2,
sum(case when monthid=my3 then dr_amt else null end ) as dr_amt_3,
sum(case when monthid=my4 then dr_amt else null end ) as dr_amt_4,
sum(case when monthid=my5 then dr_amt else null end ) as dr_amt_5,
sum(case when monthid=my6 then dr_amt else null end ) as dr_amt_6

from pre_mnth a 
left join prod_db.dsg_portfolio.mom_tran_crdr b 
on a.crn=b.crn
group by a.crn 

""")
crdr = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/crdr/month={mnthid}/crdr_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
crdr.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




######### demogs

sql = connection.execute("""
 select distinct  a.crn, b.occupation, dob, total_rv,c.first_credit_date,c.first_credit_amt,tier_cate, primary_miss

from mydb.dsg_portfolio.fd_nu_scoring  a 
left join prod_db.dsg_portfolio.base_dashboard_811 b 
on a.crn=b.crn
left join prod_db.dsg_services.funding_file_monthly c 
on a.crn=c.crn
 where report_month =(select max(report_month) from prod_db.dsg_services.funding_file_monthly)
 and month=(select max(month) from prod_db.dsg_portfolio.base_dashboard_811)

""")
demogs = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/demogs/month={mnthid}/demogs_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
demogs.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



################ mobile login


sql = connection.execute("""

    select distinct b.crn,
    sum(case when current_date - cast(login_time as date) <=90 then 1 else 0 end ) as login_3m,
    sum(case when current_date - cast(login_time as date) >90 then 1 else 0 end ) as login_6m
    from 
    prod_db.dwh_dmrt.uc5_convenience_report_details_login a
    join mydb.dsg_portfolio.fd_nu_scoring  b 
    on a.crn=b.crn
    where current_date - cast(login_time as date) <=180
    group by b.crn
""")
demogs = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/mb/month={mnthid}/mb_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
demogs.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




######### cibil

sql = connection.execute("""

      with
      rep_mnth as (
        select
          crn,
          max(report_month) as report_month
        from
          prod_db.dwh_stg.stg_ebix_cibil_data_tl
        group by
          crn
      )
    select distinct
      a.crn,
      loan_status,
      date_opened,
      date_closed,
      loan_type,
      sanction_amount
    from
      prod_db.dwh_stg.stg_ebix_cibil_data_tl a
      join rep_mnth b on a.crn = b.crn
      and a.report_month = b.report_month
      join mydb.dsg_portfolio.fd_nu_scoring c on a.crn = c.crn
    where
       loan_type in ('Credit Card','Home Loan','Personal Loan','Consumer Loan')
      and current_date > date_opened
      and (
        (date_closed - current_date) > 30
        or date_closed is null
      )
""")
cibil = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/cibil/month={mnthid}/cibil_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
cibil.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

scoring_base=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/fd_scoring/month={mnthid}/scoring_{mnthid}.csv'.format(mnthid=mnthid))

demogs=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/demogs/month={mnthid}/demogs_{mnthid}.csv'.format(mnthid=mnthid))

amb=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/amb/month={mnthid}/amb_{mnthid}.csv'.format(mnthid=mnthid))


tran=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/crdr/month={mnthid}/crdr_{mnthid}.csv'.format(mnthid=mnthid))

mb=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/mb/month={mnthid}/mb_{mnthid}.csv'.format(mnthid=mnthid))

cibil=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/cibil/month={mnthid}/cibil_{mnthid}.csv'.format(mnthid=mnthid))



scoring_base=scoring_base.rename(columns={'fkycdate':'fkyc_date'})


demogs['dob']=pd.to_datetime(demogs['dob'])
demogs['first_credit_date']=pd.to_datetime(demogs['first_credit_date'])
demogs=demogs.drop_duplicates('crn')
df=pd.merge(scoring_base,demogs,on='crn',how='left')


# df['reference_mnth']=pd.to_datetime(df['reference_mnth'])
df['dob']=pd.to_datetime(df['dob'])

df['age']=((datetime.today()-df['dob']).dt.days)/365

df['accnt_opn_date']=pd.to_datetime(df['accnt_opn_date'],format='ISO8601')
df['fkyc_date']=pd.to_datetime(df['fkyc_date'])
df['first_credit_date']=pd.to_datetime(df['first_credit_date'])


df['days_to_fkyc']=(df['fkyc_date']-df['accnt_opn_date']).dt.days


df['vintage_fkyc']=(datetime.today()-df['fkyc_date'])/np.timedelta64(30, 'D')
df['days_to_funding']=(df['accnt_opn_date']-df['first_credit_date']).dt.days


mb['login_inc']=(mb['login_3m']-mb['login_6m'])/mb['login_6m']
mb['login_inc']=np.where(mb['login_6m']==0,mb['login_3m'],mb['login_inc'])


df=pd.merge(df,amb,on='crn', how='left')

df=pd.merge(df,tran,on='crn', how='left')


df=pd.merge(df,mb[['crn','login_3m','login_inc']],on='crn',how='left')


cibil_gp=cibil.groupby(['crn','loan_type']).agg({'loan_type':'count','sanction_amount':'sum'}).rename(columns={'loan_type':'count_loans'}).unstack()

cibil_gp.columns=cibil_gp.columns.to_series().str.join("_")

cibil_gp=cibil_gp.reset_index()
cibil_gp=cibil_gp.fillna(0)
cibil_gp=cibil_gp.rename(columns={'count_loans_Consumer Loan':'CD_cnt'
                         , 'count_loans_Credit Card':'CC_cnt',
       'count_loans_Home Loan':'HL_cnt', 'count_loans_Personal Loan':'PL_cnt',
       'sanction_amount_Consumer Loan':'CD_amt', 'sanction_amount_Credit Card':'CC_amt',
       'sanction_amount_Home Loan':'HL_amt', 'sanction_amount_Personal Loan':'PL_amt'
                        })

df=pd.merge(df,cibil_gp,how='left',on='crn')


df=df.drop_duplicates("crn")
df['amb_3m']=df[['amb_1','amb_2','amb_3']].mean(axis=1)
df['amb_6m']=df[['amb_4','amb_5','amb_6']].mean(axis=1)

df['amb_3m']=df['amb_3m'].fillna(0)
df['amb_bkt']=pd.cut(df['amb_3m'],bins=[-float('inf'),0,100,1000,5000,10000,50000,float('inf')],
       labels=['1. <=0','2. 1-100','3. 101-1k','4.1k-5k','5.5k-10k','6. 10k-50k','7. >50k'])

df['cr_cnt_3m']=df[['cr_cnt_1', 'cr_cnt_2', 'cr_cnt_3']].mean(axis=1)
df['cr_cnt_6m']=df[['cr_cnt_4', 'cr_cnt_5', 'cr_cnt_6']].mean(axis=1)
df['dr_cnt_3m']=df[['dr_cnt_1', 'dr_cnt_2', 'dr_cnt_3']].mean(axis=1)
df['dr_cnt_6m']=df[['dr_cnt_4', 'dr_cnt_5', 'dr_cnt_6']].mean(axis=1)

df['cr_amt_3m']=df[['cr_amt_1', 'cr_amt_2', 'cr_amt_3']].mean(axis=1)
df['cr_amt_6m']=df[['cr_amt_4', 'cr_amt_5', 'cr_amt_6']].mean(axis=1)
df['dr_amt_3m']=df[['dr_amt_1', 'dr_amt_2', 'dr_amt_3']].mean(axis=1)
df['dr_amt_6m']=df[['dr_amt_4', 'dr_amt_5', 'dr_amt_6']].mean(axis=1)

df['cr_cnt_diff']=df['cr_cnt_3m']-df['cr_cnt_6m']
df['cr_amt_diff']=df['cr_amt_3m']-df['cr_amt_6m']
df['dr_cnt_diff']=df['dr_cnt_3m']-df['dr_cnt_6m']
df['dr_amt_diff']=df['dr_amt_3m']-df['dr_amt_6m']

df['cr_cnt_inc_ratio']=(df['cr_cnt_3m']-df['cr_cnt_6m'])/df['cr_cnt_6m']
df['cr_amt_inc_ratio']=(df['cr_amt_3m']-df['cr_amt_6m'])/df['cr_amt_6m']
df['dr_cnt_inc_ratio']=(df['dr_cnt_3m']-df['dr_cnt_6m'])/df['dr_cnt_6m']
df['dr_amt_inc_ratio']=(df['dr_amt_3m']-df['dr_amt_6m'])/df['dr_amt_6m']


df['amb_1_3_mnth']=df['amb_1']/df['amb_3']
df['amb_1_3_mnth']=np.where(df['amb_1_3_mnth']==float('inf'),df['amb_1'],df['amb_1_3_mnth'])
df['amb_1_3_mnth']=df['amb_1_3_mnth'].fillna(0)


df['amb_3_6_diff']=(df['amb_3m']-df['amb_6m'])/df['amb_6m']
df['amb_3_6_diff']=np.where(df['amb_3_6_diff']==float('inf'),df['amb_3m'],df['amb_3_6_diff'])
df['amb_3_6_diff']=df['amb_3_6_diff'].fillna(0)

df['dr_cr_cnt_ratio']=df['dr_cnt_3m']/df['cr_cnt_3m']
df['dr_cr_cnt_ratio']=df['dr_cr_cnt_ratio'].fillna(0)


df['dr_cr_amt_ratio']=df['dr_amt_3m']/df['cr_amt_3m']
df['dr_cr_ats_ratio']=(df['dr_amt_3m']/df['dr_cnt_3m'])/(df['cr_amt_3m']/df['cr_cnt_3m'])
df['dr_cr_amt_ratio']=df['dr_cr_amt_ratio'].fillna(0)
df['dr_cr_ats_ratio']=df['dr_cr_ats_ratio'].fillna(0)
df['dr_cr_amt_ratio']=np.where(df['dr_cr_amt_ratio']==float('inf'),df['dr_amt_3m'],df['dr_cr_amt_ratio'])

df['occupation']=df['occupation'].replace({'Service - Private Sector':'Salaried',
    'Professional':'Salaried','Service - Public Sector':'Salaried',
    'Service - Government Sector':'Salaried','Self Employees Professional (SEP)':'Self Employed',
     'SENP - Job Worker':'Self Employed', 
       'Self Employees Professional (SEP)':'Self Employed', 'SENP - Retail Trader':'Self Employed',
       'SENP - Others':'Self Employed', 'SENP - Wholesale Trader':'Self Employed',
       'SENP - Service Industry':'Self Employed', 'Self Employed Non Professional':'Self Employed',
       'SENP - Distributor':'Self Employed', 'SENP - Manufacturer':'Self Employed','Business':  'Self Employed',
                                    'Non Working':'Others'                
    })

df['occupation']=df['occupation'].fillna('Others')


df['age']=(datetime.today()-df['dob']).dt.days/365
df['days_to_fkyc']=(df['fkyc_date']-df['accnt_opn_date']).dt.days
df['days_to_funding']=(df['first_credit_date']-df['accnt_opn_date']).dt.days
# df['primary_miss']=np.where(df['primary_miss']=='PRIMARY',1,0)


# removed 6m variables because of collinearity
# remove total rv
base=df[['crn', 
        'occupation', 
       'first_credit_amt', 'tier_cate',  'age', 'days_to_fkyc',
       'vintage_fkyc', 'days_to_funding', 
        'login_3m', 'login_inc', 'amb_3m',
       'amb_bkt', 'cr_cnt_3m',  'dr_cnt_3m', 
       'cr_amt_3m',  'dr_amt_3m', 'cr_cnt_diff',
       'cr_amt_diff', 'dr_cnt_diff', 'dr_amt_diff', 'cr_cnt_inc_ratio',
       'cr_amt_inc_ratio', 'dr_cnt_inc_ratio', 'dr_amt_inc_ratio',
       'dr_cr_cnt_ratio', 'dr_cr_amt_ratio', 'amb_1_3_mnth', 'amb_3_6_diff',
       'dr_cr_ats_ratio',
#          'dmat_tag', 'trdng_flag', 'gen_insurnc_tag', 'mf_final_tag','dc_flag'
         'CD_cnt', 'CC_cnt', 'HL_cnt', 'PL_cnt', 'CD_amt', 
       'CC_amt', 'HL_amt', 'PL_amt'
#          ,'sec_amb', 'sec_cr'
        ]]


cols=base.drop(columns=['days_to_fkyc','vintage_fkyc','days_to_funding','amb_bkt']).columns
for i in cols:
    # print(i)
    base[i]=base[i].fillna(0)
    
base['days_to_funding']=base['days_to_funding'].fillna(999)
base=base.dropna(subset=['days_to_fkyc'],axis='index')

base[['login_3m','login_inc']]=base[['login_3m','login_inc']].fillna(0)


def one_hot(df, cols,drop_og_variable=False):
    """
    df:pandas DataFrame
    cols: a list of columns to encode 
    return a DataFrame with one-hot encoding
    """
    for each in cols:
        dummies = pd.get_dummies(df[each], prefix=each, drop_first=drop_og_variable)
        dummies.replace({True:'1',False:'0'},inplace=True)
        df = pd.concat([df, dummies], axis=1)
    df.drop(cols,axis=1,inplace=True)
    return df

cols=['occupation','amb_bkt','tier_cate']
base=one_hot(base,cols,True)


cols= [ 'first_credit_amt', 'age', 'days_to_fkyc', 'vintage_fkyc',
       'days_to_funding', 'login_3m', 'login_inc', 'amb_3m', 'cr_cnt_3m',
       'dr_cnt_3m', 'cr_amt_3m', 'dr_amt_3m', 'cr_cnt_diff', 'cr_amt_diff',
       'dr_cnt_diff', 'dr_amt_diff', 'cr_cnt_inc_ratio', 'cr_amt_inc_ratio',
       'dr_cnt_inc_ratio', 'dr_amt_inc_ratio', 'dr_cr_cnt_ratio',
       'dr_cr_amt_ratio', 'amb_1_3_mnth', 'amb_3_6_diff', 'dr_cr_ats_ratio',
       'CD_cnt', 'CC_cnt', 'HL_cnt', 'PL_cnt', 'CD_amt', 'CC_amt', 'HL_amt',
       'PL_amt'
      ]

#### get the percentiles from train , scaler and model file

model_path="811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/model_files/"
bucket_name='kotak-811-cdp-peak-write'

thres=pd.read_excel('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/model_files/thresholds_for_outliers.xlsx')


with tempfile.TemporaryFile() as fp:
    s3.download_fileobj(Fileobj=fp, Bucket=bucket_name, Key=model_path+"scaler.pkl")
    fp.seek(0)
    scaler = joblib.load(fp)
with tempfile.TemporaryFile() as fp:
    s3.download_fileobj(Fileobj=fp, Bucket=bucket_name, Key=model_path+"rf_model_mar.pkl")
    fp.seek(0)
    model = joblib.load(fp)


for col in thres.Columns:
    percentile_0 = thres[thres['Columns']==col]['min'].values[0]

    percentile_1 = thres[thres['Columns']==col]['max'].values[0]
    print(col," ",percentile_0)
    print(col," ",percentile_1)

    base[col]=np.where(base[col]<percentile_0,percentile_0,base[col])
    base[col]=np.where(base[col]>percentile_1,percentile_1,base[col])


scaled=scaler.transform(base[['days_to_fkyc',
 'vintage_fkyc',
 'login_3m',
 'login_inc',
 'amb_3m',
 'cr_cnt_3m',
 'dr_cnt_3m',
 'cr_amt_3m',
 'dr_amt_3m',
 'cr_amt_diff',
 'dr_cnt_diff',
 'dr_amt_diff',
 'cr_amt_inc_ratio',
 'dr_amt_inc_ratio',
 'dr_cr_cnt_ratio',
 'dr_cr_amt_ratio',
 'amb_1_3_mnth',
 'amb_3_6_diff',
 'dr_cr_ats_ratio',
 'CC_cnt',
 'PL_cnt',
 'CC_amt',
 'PL_amt',
 'amb_bkt_3. 101-1k',
 'amb_bkt_7. >50k']])


bucket = 'kotak-811-cdp-peak-write'
write_path = 'kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/dataset/month={mnthid}/dataset_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
base.to_csv(buffer, index=False)
buffer.seek(0)

y_pred=model.predict(scaled)
y_pred_proba=model.predict_proba(scaled)[:,1]
base['y_pred_proba']=y_pred_proba
base['y_pred']=y_pred

base['decile']=10-pd.qcut(base['y_pred_proba'], 10, labels = False) 
gp_total=base.groupby(['decile']).agg({'y_pred_proba':['count','max','min']}).reset_index()



sql = connection.execute(
    """
with live_fd_crn as (
select distinct crn from 
mydb.dsg_portfolio.fd_nu_scoring

)


select * from 
(

select b.crn,
 max(amb_priority) as priority

from 

(select distinct crn 
from 
mydb.dsg_portfolio.fd_nu_scoring
)
 b 

left join 
(select cust_id,max(current_day_bal) as amb , (100*cume_dist() over (order by amb desc))::int  as amb_priority
 from dwh_dmrt.dm_uc1_dly_amb where prodct_type='SBA' 
 group by cust_id) am 
on b.crn=am.cust_id


group by b.crn )
"""
     )
persona = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = 'kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/persona/month={mnthid}/persona_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
persona.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

persona['crn']=persona['crn'].astype('int')
base=pd.merge(base,persona[['crn','priority']],on='crn',how='left')


sql = connection.execute(
 """
select distinct a.crn,cluster_name
from 
mydb.dsg_portfolio.fd_nu_scoring a 
left join
dsg_tpp_xsell.dmart_segment_mapping b 
on a.crn=b.crn

where updated_month=(select max(updated_month) from dsg_tpp_xsell.dmart_segment_mapping )
    """    )
segment = pd.DataFrame(sql.fetch_dataframe())


bucket = 'kotak-811-cdp-peak-write'
write_path = 'kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/segment/month={mnthid}/segment_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
segment.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

segment['crn']=segment['crn'].astype('int')

base=pd.merge(base,segment,on='crn',how='left')


campaign_base=base[(base['decile'].isin([1,2,3,4]))| (base['decile'].isin([5,6,7,8]) &base['cluster_name'].isin(['Credit Hungry',
'Credit Worthy',
'Digi-Spenders_ ',
 'Disengaged Business', 'Disengaged Salaried', 'Disengaged Student',
'Saver Housewives']))][['crn','cluster_name','decile','amb_3m','y_pred_proba','priority']]


bucket = 'kotak-811-cdp-peak-write'
write_path = 'kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/full_base/month={mnthid}/full_base_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
campaign_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)







