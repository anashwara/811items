import psycopg2
import shutil
import pandas as pd
import datetime
import redshift_connector    
from datetime import timedelta
import io
import boto3



# from s3fs.core import S3FileSystem
from datetime import timedelta
pd.set_option('display.float_format', lambda x: '%.3f' % x)

from common_utils.helper import RedshiftUser

session = boto3.Session()

s3 = session.client('s3')

today=dt.date.today()

if today.day <15 :
    mnthid=str(today.year)+"-"+str(today.month)
    last_month = today.replace(day=1) + dt.timedelta(days=-10)

    ref_d1=dt.date.today().replace(day=1) - timedelta(days=1)
    last_mnth=str(last_month.year)+"-"+str(last_month.month)

elif today.day>=15:
    last = today.replace(day=28)
    last_month = last + dt.timedelta(days=10)
    mnthid=str(last_month.year)+"-"+str(last_month.month)
    ref_d1=dt.date.today().replace(day=1) - timedelta(days=45)
    last_mnth=str(last.year)+"-"+str(last.month)



    
ref_d2=ref_d1.replace(day=1) - timedelta(days=1)
ref_d3=ref_d2.replace(day=1) - timedelta(days=1)
ref_d4=ref_d3.replace(day=1) - timedelta(days=1)
ref_d5=ref_d4.replace(day=1) - timedelta(days=1)
ref_d6=ref_d5.replace(day=1) - timedelta(days=1)

login=pd.to_datetime(ref_d4).strftime("%Y-%m-%d")

ref_m1=ref_d1.year*100+ref_d1.month
ref_m2=ref_d2.year*100+ref_d2.month
ref_m3=ref_d3.year*100+ref_d3.month
ref_m4=ref_d4.year*100+ref_d4.month
ref_m5=ref_d5.year*100+ref_d5.month
ref_m6=ref_d6.year*100+ref_d6.month


redshift_username = 'af_dsg_portfolio'
redshift_password  = RedshiftUser(redshift_username).get_password().decode("utf-8")

conn = redshift_connector.connect(
     host="prod-de-redshift-cluster.cgjabuq7ccxq.ap-south-1.redshift.amazonaws.com",
     database="prod_db",
     port=5439,
     user=redshift_username,
     password=redshift_password)


connection: redshift_connector.Cursor = conn.cursor()


# #811 brand
sql = connection.execute("""
    with saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A' 
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
),
crns as (
select distinct  a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn
),
crdr as (
select crn 

from  (

select crn, 
case when month_year={m1} then cr_amt end as m1_cr_amt,
case when month_year={m1} then dr_amt end as m1_dr_amt,
case when month_year={m2} then cr_amt end as m2_cr_amt,
case when month_year={m2} then dr_amt end as m2_dr_amt,
case when month_year={m3} then cr_amt end as m3_cr_amt,
case when month_year={m3} then dr_amt end as m3_dr_amt,
case when month_year={m4} then cr_amt end as m4_cr_amt,
case when month_year={m4} then dr_amt end as m4_dr_amt


from dsg_portfolio.mom_tran_crdr
where crn in (select distinct crn from crns)
)
group by crn
having sum(m1_cr_amt)>=9000 and sum(m1_dr_amt)>=9000
and sum(m2_cr_amt)>=10000 and sum(m2_dr_amt)>=10000
and sum(m3_cr_amt)>=10000 and sum(m3_dr_amt)>=10000
and sum(m4_cr_amt)>=10000 and sum(m4_dr_amt)>=10000

),
amb as (

select a.crn, sum(m5_cr_amb) as amb

from dsg_portfolio.mom_amb a 
join crns b 
on a.crn::bigint=b.crn::bigint
where yr_id=2024
and m1_cr_amb>=15000
and m2_cr_amb>=15000
and m3_cr_amb>=15000
and m4_cr_amb>=15000

group by a.crn
),
login as (
select distinct a.crn, count(login_time) as mb_logins 

from dwh_dmrt.uc5_convenience_report_details_login a
join crns b 
on a.crn::bigint=b.crn::bigint
where login_time>='{login}'
group by a.crn 
having mb_logins>=10

)
select distinct a.crn,amb
from crdr a 
join amb b 
on a.crn::bigint=b.crn::bigint
join login c 
on a.crn::bigint=c.crn::bigint
where a.crn not in (select crn from dsg_portfolio.rel_td_account_details where 
prodct_code not like '%RD%'
and prodct_code not like '%FF%'
)

-- 1. Min AMB of 15k kept consistently since 4 months
-- 2. Monthly credits and debits  of min 10k happening since 4 months
-- 3. More than 10 times logged into mb1.0 or 811app since 4 months

""".format(login=login,m1=ref_m1,m2=ref_m2,m3=ref_m3,m4=ref_m4,m5=ref_m5,m6=ref_m6 ))
brand = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/811brand/month={ref_m1}/811brand_{ref_m1}.csv'.format(ref_m1=mnthid)

buffer = io.BytesIO()
brand.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


#loan maturity

sql = connection.execute("""
 with
  rep_mnth as (
    select
      crn,
      max(report_month) as report_month
    from
      dwh_stg.stg_ebix_cibil_data_tl
    group by
      crn
  ),
     saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A' 
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
),
crns as (
select distinct  a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn
)
  
select 
distinct
  a.crn,tenor,
interest_rates, 
  loan_status,
  date_opened,
  date_closed,
  loan_type,
  sanction_amount, dateadd(month, tenor, cast(date_opened as date)) as predicted_cls_date,
  emi,out_standing_balance,monthly_annual_indicator,actual_paymt_amt,dpd_string
from
  dwh_stg.stg_ebix_cibil_data_tl a
  join rep_mnth b on a.crn = b.crn
  and a.report_month = b.report_month
  join crns c 
on a.crn=c.crn
where
  loan_type in 
  (
'Short Term Personal Loan',
'Home Loan',
'Loan Against Bank Deposits',
'Business Loan Against Bank Deposits',
'Used Car Loan',
'P2P Auto Loan',
'Property Loan',
'Two-wheeler Loan',
'Education Loan',
'Microfinance - Business Loan',
'Personal Loan',
'Consumer Loan',
'Priority Sector - Gold Loan',
'P2P Education Loan',
'Business Loan - General',
'Business Non-Funded Credit Facility - Priority Sector - Agriculture',
'Microfinance - Personal Loan',
'Auto Loan',
'Microfinance - Home Loan'

)
  
  and (
   ( (cast(current_date as date)- cast(date_closed as date)) < 90
      and   (cast(current_date as date)- cast(date_closed as date)) >= 0)

   or ( dateadd(month, tenor, cast(date_opened as date)) <dateadd(month,1,current_date)
  and  dateadd(month, tenor, cast(date_opened as date)) >current_date
   )
  )
  and a.crn not in (select crn from dsg_portfolio.rel_td_account_details where 
prodct_code not like '%RD%'
and prodct_code not like '%FF%'
)
""")
loan_maturity = pd.DataFrame(sql.fetch_dataframe())



loan_maturity['dpd_final']=loan_maturity['dpd_string'].apply(lambda x:x.replace('STD','000').replace('XXX','000').replace('UB','00')
                                      .replace('S','0').replace('L','0').replace('MA','00').replace('DBT','000'))

#filtering out non defaulted customers
loan_maturity=loan_maturity[loan_maturity.dpd_final.astype('float')==0]

loan_maturity['date_closed']=pd.to_datetime(loan_maturity['date_closed'])
loan_maturity['date_opened']=pd.to_datetime(loan_maturity['date_opened'])

loan_maturity['loan_paid_tenure']=(loan_maturity['date_closed']-loan_maturity['date_opened']).dt.days/30
loan_maturity['closed_mn_yr']=loan_maturity['date_closed'].dt.to_period('M')
loan_maturity=loan_maturity[(loan_maturity['date_closed']>=pd.to_datetime(ref_d3)) | (loan_maturity['date_closed'].isna())]

closed=loan_maturity[(loan_maturity['sanction_amount']>10000)&(~loan_maturity['date_closed'].isna())]
closed['predicted_emi']=closed['sanction_amount']/closed['loan_paid_tenure']

closed_base=closed[(closed['predicted_emi']>5000)&(closed['loan_paid_tenure']>3)]



live=loan_maturity[(loan_maturity['loan_status']=='Live')]
live['loan_paid_tenure']=(pd.to_datetime(datetime.date.today())-live['date_opened']).dt.days/30
live['predicted_emi']=live['sanction_amount']/live['loan_paid_tenure']
live_base=live[(live['predicted_emi']>5000)&(live['loan_paid_tenure']>3)]

final_base=pd.concat([closed_base,live_base],axis=0)
final_base=final_base.drop_duplicates(['crn','date_opened','loan_type','sanction_amount'])
campaign_base=final_base.groupby('crn').agg({'predicted_emi':'sum'}).reset_index()

campaign_base=campaign_base.drop_duplicates('crn')


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/loan_maturity/month={}/loan_maturity_{}.csv'.format(mnthid,mnthid)

buffer = io.BytesIO()
campaign_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



##########Gold

sql = connection.execute("""
    with saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A' 
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
),
crns as (
select distinct  a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn
)
select distinct
a.crn, tran_id,type_of_tran,tran_amt,tran_desc
from dwh_dmrt.dm_uc3_transaction_classification a
join crns b 
on a.crn=b.crn
where tran_desc like '%JEWEL%'
and cr_dr_indicator='DR'
and cast(tran_date as date)>={}
and a.crn not in (select crn from dsg_portfolio.rel_td_account_details where 
prodct_code not like '%RD%'
and prodct_code not like '%FF%'
)
""".format(ref_d6))
jewel = pd.DataFrame(sql.fetch_dataframe())


jewel=jewel[['crn', 'tran_id','type_of_tran','tran_amt','tran_desc']]
jewel=jewel[jewel['type_of_tran'].isin(['UPI', 'POS', 'FUNDT', 'INWR', 'NEFT', 'IMPS', 'ECOM', 
       'RTGS', 'CCPMT', 'NAV', 'TXPMT', 'IMT','ADCHRG'])]
jewel=jewel[~((jewel['tran_desc'].str.contains('FASHION'))|jewel['tran_desc'].str.contains('Fashion'))]

crn_wise_spends=jewel.groupby('crn')['tran_amt'].sum().reset_index()



    
sql = connection.execute("""
 with saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A' 
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
),
crns as (
select distinct  a.accnt_num, a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn
)

---select count(distinct crn) from (
select c.crn, sum(amount)/100 as total_amt 

from dwh_stg.stg_upi_tbl_cbs_tranlog_encrypt a
join  crns c 
on a.customeraccount=c.accnt_num
where mcccode in ('5094')
and txn_date>={}

and type='DEBIT'
and crn not in (select crn from dsg_portfolio.rel_td_account_details where 
prodct_code not like '%RD%'
and prodct_code not like '%FF%'
)

group by crn

---having total_amt >10000
---)

""".format(ref_d6))
gold_upi = pd.DataFrame(sql.fetch_dataframe())



gold_upi=gold_upi[(~gold_upi['crn'].isin(crn_wise_spends.crn.unique()))&(gold_upi['total_amt']>4000)].rename(columns={'total_amt':'tran_amt'})
crn_wise_spends=crn_wise_spends[crn_wise_spends['tran_amt']>4000]



sql = connection.execute("""
 with saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A' 
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
),
crns as (
select distinct  a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn
)
select 

a.CRN,
              DR_CARD_ID as MASKED_CARD_NUM,
              TRAN_DATE,
              FINANCL_NON_FINANCL,
              TRAN_CHNNEL,
              TRAN_AMT,
              merchnt_id, mcc_code
from dwh_CDR.FCT_DEBIT_CARD_TXN a
join  crns c 
on a.crn=c.crn


where 
              TRAN_DESTINATION in( '429393') and
              TRAN_CHNNEL in ('POS','ECOM') and
              CURRENT_FLAG = 'Y' and
              RESP_CODE = 0 and 
              merchnt_id in ('5094')
              and cast(tran_date  as date)>={}
              
              and a.crn not in (select crn from dsg_portfolio.rel_td_account_details where 
prodct_code not like '%RD%'
and prodct_code not like '%FF%'
)
                
""".format(ref_d6))
gold_dc = pd.DataFrame(sql.fetch_dataframe())

gold_dc=gold_dc.groupby('crn')['tran_amt'].sum().reset_index()
gold_dc=gold_dc[(~gold_dc['crn'].isin(crn_wise_spends.crn.unique()))&(gold_dc['tran_amt']>4000)]
gold_base=pd.concat([pd.concat([crn_wise_spends,gold_upi],axis=0),gold_dc],axis=0)


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/gold_base/month={}/gold_base_{}.csv'.format(mnthid,mnthid)

buffer = io.BytesIO()
gold_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




#################FD EU


sql = connection.execute("""
with 
 saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A' 
),

live_fd_crn as (
select distinct crn from 
dsg_portfolio.rel_td_account_details
where accnt_cls_date is null
and td_cust_clssfcaton_code in ('KSEL','KNOW','KJIFI','K_NOB')
and prodct_code not like '%FF%'
and prodct_code not like '%RD%'
)
select 
distinct a.*
from 
(

select b.crn,
max(case when c.crn is null then 'inactive' else 'active' end ) as fd_live,
 max(amb_priority) as priority

from 
 
(select distinct crn 
from 
dsg_portfolio.rel_td_account_details
where prodct_code not like '%FF%'
and prodct_code not like '%RD%'
and td_cust_clssfcaton_code in ('KSEL','KNOW','KJIFI','K_NOB')

)
 b 
left join live_fd_crn c 
on b.crn=c.crn
left join 
(select cust_id,max(cr_inr_amb) as amb , (100*cume_dist() over (order by amb desc))::int  as amb_priority
 from dwh_dmrt.dm_uc1_dly_amb
 where prodct_type='SBA'
 group by cust_id) am 
on b.crn=am.cust_id


group by b.crn ) a 
join saving_crn b 
on a.crn=b.crn
""")  
fd_eu = pd.DataFrame(sql.fetch_dataframe())



bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_eu/month={}/fd_eu_{}.csv'.format(mnthid,mnthid)

buffer = io.BytesIO()
fd_eu.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



###############Activmoney


sql = connection.execute("""
with saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A'
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
),
crns as (
select distinct  a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn
),
fkyc_base as (
select distinct crn, fkyc_date 
from 
(select crn, max(fkyc_date) as fkyc_date from 
dsg_portfolio.fkyc_base_ntb
where fkyc_date is not null
group by crn
)),
max_updated_date as (
select crn, max(updated_at_ist) as max_date 
from app_811_onb_prod_active_money.tbl_users
group by crn
),
activ_money as (
select distinct a.crn
from app_811_onb_prod_active_money.tbl_users a 
join max_updated_date b 
on a.crn=b.crn 
and a.updated_at_ist=b.max_date
and status=1
)

select distinct a.crn, amb,
case when amb_gt_500 =1  or debit_active_60 =1 or credit_active_60 =1 
 or digital_act_30 =1 then 1 end as active_811
 from dsg_portfolio.base_dashboard_811 a 
 join crns b 
 on a.crn=b.crn
 join fkyc_base c 
 on a.crn=c.crn
where month=(select max(month) from dsg_portfolio.base_dashboard_811)
and flgprimary!=1
and active_811=1
and a.crn not in (select crn from app_811_onb_prod_active_money.tbl_users)

""")
activmoney = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/activmoney/month={ref_m1}/activmoney_{ref_m1}.csv'.format(ref_m1=mnthid)


buffer = io.BytesIO()
activmoney.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


######### ntb

sql = connection.execute("""
with ntb_amb as (

select distinct crn::varchar, sum(previous_day_bal)::varchar as measure,
'amb' as measuring_param
from dsg_portfolio.fkyc_base_ntb a 
join dwh_dmrt.dm_uc1_dly_amb b 
on a.crn=b.cust_id
where fkyc_date>={ref_d3}
and clssfcaton in ('KSEL','KNOW','KJIFI','K_NOB')
and previous_day_bal>1000

group by a.crn
),

rep_mnth as (
        select
          crn,
          max(report_month) as report_month
        from
          dwh_stg.stg_ebix_cibil_data_tl
        group by
          crn
      ),
cibil as (
  select distinct
      a.crn::varchar, max(tu_score_1)::varchar as measure, 
      'cibil' as measuring_param

    from
      dwh_stg.stg_ebix_cibil_data_tl a
      join rep_mnth b on a.crn = b.crn
      and a.report_month = b.report_month
      join dsg_portfolio.fkyc_base_ntb c on a.crn = c.crn
    where
       tu_score_1>750
       and fkyc_date>={ref_d3}
       group by a.crn

)

select distinct * from ntb_amb 
union select distinct * from cibil


""".format(ref_d3=ref_d3))
    
ntb =pd.DataFrame(sql.fetch_dataframe())


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/ntb/month={}/ntb_{}.csv'.format(mnthid,mnthid)


buffer = io.BytesIO()
ntb.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


################## 811 base 


sql = connection.execute("""

with saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A'
and schme_code in ('LSJIFN','LSDIGI','SJIFN','SDIGI')
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
)
select distinct crn from (
select distinct  a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn
)


""")
base_811 = pd.DataFrame(sql.fetch_dataframe())

bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/base_811/month={mnthid}/base_811.csv'.format(mnthid=mnthid)


buffer = io.BytesIO()
base_811.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


###################
travel medical - the table rca_dod_cr_dr_keyword is not updated in in redshift. hence using older data. 


sql = connection.execute("""
   
   
select crn, category, sum(dr_amt) as amt
from dsg_external.rca_dod_cr_dr_keyword
where category in ('Medical','Travel')
and tran_sub_type='CI'
and tran_date>'2024-08-11'
and crn in (

   select crn from   prod_db.dsg_services.funding_file_monthly a
    WHERE  current_schme_code in ('LSJIFN','LSDIGI','SJIFN','SDIGI')   
and cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
and report_month=(select max(report_month) from prod_db.dsg_services.funding_file_monthly)
and crn not in (
select crn from dsg_portfolio.rel_td_account_details

)
)
group by crn,category
having amt>3000

""".format(ref_d6=ref_d6 ))
tm = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/travel_medical/month={mnthid}/travel_medical_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
tm.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


# #####################




####################
# KRA


sql = connection.execute("""
   
   with kra as (
    SELECT DISTINCT crn::BIGINT as crn
    FROM prod_db.dsg_tpp_xsell.kra_base_40 kb
    UNION 
    SELECT DISTINCT crn_f::BIGINT as crn
    FROM kotak811_external.kra_new kb
    )
    select distinct crn,sum(current_day_bal) as eop 
    from kra a 
    
    join dwh_dmrt.dm_uc1_dly_amb b 
    on a.crn=b.cust_id
where  prodct_type='SBA'
group by crn


""")
kra = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/kra/month={mnthid}/kra_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
kra.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


#####################


####################
# GI


sql = connection.execute("""
   
with insurance as(
With Enrollment_agile as (
SELECT                         G.PROPOSAL_NO,
                                                                                                G.TOTAL_PREMIUM_AMOUNT,
                                                                                                CAST (G.AUTHORIZED_DATE as DATE) as Enrollment_date,
                                                                                                G.PRODUCT_ID,
                                                                                                cast(G.CANCELED_ON as DATE) as cancellation_date_enroll,
                                                                                                row_number() over(
                                partition by G.PROPOSAL_NO
                                order by
        etl_last_updated_time :: Date desc)
                                from dwh_stg.STG_AGILE_MS_PROPOSAL_MAKER G
                                INNER JOIN dwh_dmrt.DM_811_BASE F
        on F.CRN = G.CRN_NUMBER and (OUTWARD = '' OR OUTWARD IS NULL) AND account_no is not null
    )
                        SELECT           
                                   G.PROPOSAL_NO :: VARCHAR,
                                   I.INS_PRD_NM :: VARCHAR as Product_name ,
                                    G.Enrollment_date :: date ,
                                    cast(D.POLICY_EFFECTIVE_DATE as DATE) as Issuance_date,
                                    D.CRN_NUMBER,
                                    CAST(D.FUND_TRANSFER_DATE as DATE) as payment_date,
                                    D.sum_assured ,
            
                                    CASE WHEN G.cancellation_date_enroll is null THEN D.CANCELLATION_REQUEST_DATE
                                    else NULL END as cancellation_date,
                                    G.TOTAL_PREMIUM_AMOUNT as premium_amount ,
                                    D.ISPOLICYCANCELLED,
                                    CASE WHEN G.PROPOSAL_NO like '%GI%' THEN 'Group_GI'
                                    WHEN  G.PROPOSAL_NO like '%LI%' THEN 'Group_LI'
                                    else NULL END as Insurance_TYPE,
                                    Q.product :: VARCHAR as Product,
                                    Q."flag"  :: VARCHAR as channel,
                                    case when Q.product = 'Bank' and Q.final_income ~ '^[0-9\.]+$' THEN round((Q.final_income :: FLOAT * 0.25) ,2)
                                    when Q.product = 'Self' and Q.final_income ~ '^[0-9\.]+$' THEN round(Q.final_income:: FLOAT ,2)
                                    ELSE NULL END as Income_share,
                                    CASE WHEN G.PROPOSAL_NO like '%GI%' THEN 'Total_GI'
                                    WHEN  G.PROPOSAL_NO like '%LI%' THEN 'Total_LI'
                                     else NULL END as Insurance_overall_TYPE,
                                    CASE when D.reference_no like '%R%' THEN 'YES'
                                    else NULL END as Renewal
FROM
Enrollment_agile G
LEFT JOIN dwh_stg.STG_AGILE_MS_PROPOSAL D
ON G.PROPOSAL_NO = D.PROPOSAL_NO and G.TOTAL_PREMIUM_AMOUNT = D.TOTAL_PREMIUM_AMOUNT
LEFT JOIN dwh_stg.STG_AGILE_MS_PRODUCT I
on G.PRODUCT_ID = I.PRODUCT_ID
LEFT JOIN dsg_vir_chnl.branch_xsell_group_ins_channel_mapped Q
on  G.PROPOSAL_NO :: VARCHAR  = Q."kmbl_system_reference_no" :: VARCHAR
WHERE --G.Enrollment_date  >= '2023-09-01'
G.Enrollment_date > {ref_d6}
--CURRENT_DATE - INTERVAL'12 month'
AND G.row_number = 1
AND (Issuance_date is null OR G.Enrollment_date <= Issuance_date)
UNION
SELECT
                                                                G.policy_num :: VARCHAR as PROPOSAL_NO,
                                                           
                                                                G.PRODCT_NAME :: VARCHAR as Product_name,
                                                                G.PROPOSAL_DATE :: date  as Enrollment_date,
                                                                G.POLICY_INCEPTION_DATE as Issuance_date,
                                                                G.CRN as CRN_NUMBER,
                                                                G.TRAN_DATE as payment_date,
                                                    regexp_replace(G.SUM_INSURED , '[^0-9]*', '') :: FLOAT as sum_assured,
                                                    --Changed       
                                                    
                                   G.END_EFFCTVE_DATE as cancellation_date,
       NULLIF(G.recpt_amt, '') :: FLOAT      as premium_amount,  --Changed here                                                             
                                                                CASE when G.END_EFFCTVE_DATE is not null then 'Y' else NULL end as ISPOLICYCANCELLED,
                                                                'Retail_GI' as Insurance_TYPE,
                                                                Q1.product :: VARCHAR as Product,
                                                                Q1."flag"  :: VARCHAR as channel,
                                                                case when Q1.product = 'Bank' and Q1."final_income" is not null THEN                 round((Q1."final_income" :: FLOAT * 0.25) ,2)
                                                                ELSE  0.0 END as Income_share,
                                                                'Total_GI' as Insurance_overall_TYPE,
                                                                CASE when G.busns_type like '%Renewal%' THEN 'YES'
                                                                else NULL END as Renewal
FROM dwh_cdr.DIM_TPP_PRODUCT_GI G
INNER JOIN dwh_dmrt.DM_811_BASE D on G.CRN=D.CRN and (OUTWARD = '' OR OUTWARD IS NULL) AND account_no is not null
LEFT JOIN dsg_vir_chnl.branch_xsell_retail_gi_channel_mapped Q1
on G.policy_num :: FLOAT = Q1."policy_no" :: FLOAT
where G.CURRENT_FLAG ='Y'
and G.PROPOSAL_DATE > {ref_d6}
AND
lower(G.prodct_name) not like '%group%'
and G.recpt_amt !='199'
             
 
 
UNION
SELECT
                                                L.POLICY_NUM :: VARCHAR as PROPOSAL_NO,
                                                L.PRODCT_DESC :: VARCHAR as Product_name,
                                                L.PDR_DATE :: DATE as Enrollment_date,
                                                cast(L.POLICY_ISSUE_DATE as DATE) as Issuance_date,
                                                L.CRN as CRN_NUMBER,
                                                L.POLICY_ISSUE_DATE as payment_date,
                                                L.SUM_ASSURED as sum_assured,
                                                cast(L.LAPSE_DATE as DATE) as cancellation_date,
                                                L.PREMIUM_AMT as premium_amount,
                                                CASE when L.LAPSE_DATE is not null then 'Y' else NULL end as ISPOLICYCANCELLED,
                                                'Retail_LI' as Insurance_TYPE,
                                                Q2.product:: VARCHAR as Product,
                                                Q2."flag" :: VARCHAR as channel,
                                                case when Q2.product = 'Bank' THEN round((Q2.final_income :: FLOAT * 0.25) ,2)
                                                ELSE Q2.final_income :: FLOAT END as Income_share,
                                                'Total_LI' as Insurance_overall_TYPE,
                                                NULL as Renewal
                                                                                                                                                                        
from
  dwh_cdr.DIM_TPP_PRODUCT_LI L
INNER JOIN dwh_dmrt.DM_811_BASE D on L.CRN=D.CRN and (OUTWARD = '' OR OUTWARD IS NULL) AND account_no is not null
left join dsg_vir_chnl.branch_xsell_retail_li_channel_mapped Q2
on L.POLICY_NUM :: VARCHAR = Q2."proposal_no" :: VARCHAR
where L.CRN is not null
AND L.CURRENT_FLAG = 'Y'
AND  L.SUM_ASSURED is not NULL
and L.pdr_date > {ref_d6}
--CURRENT_DATE - INTERVAL'1 year'
UNION
(With CTE_proposal as (
SELECT DISTINCT
MIN(a."createdat_ist") OVER (PARTITION BY a."proposalid"):: date as enrollment_date,
a."proposalid" as kmbl_sys_ref_number,
a."masterpolicyid" as master_policy_number,
a."policystartdate_ist" :: date as policy_issue_date,
a."policyenddate_ist":: date  as policy_expiry_date,
a.crn as crn,
a."grouppolicycode" as Group_product_code,
a."policycategory" as policy_category,
a."source" as channel,
a."autorenewactive",
a."source",
a."referralcode" as sourcing_emp_code,
a."proposalstatus",
CASE when a."proposalstatus" = 'FRESH' OR a."proposalstatus" = 'RENEWED' THEN 'TRUE'
ELSE 'FALSE' END as debit_done,
a."paymentId",
a."policyid",
a."masterPolicyId",
a."paymentsuccessfultime":: date as payment_date,
row_number() over(partition by a."proposalid"  order by case when a."updatedat_ist" :: date is not NULL THEN a."updatedat_ist"  :: date ELSE '2020-01-01' END  desc) as row_id_proposal
FROM dsg_external.nip_811_proposal a),
CTE_kliproposal as (
SELECT DISTINCT
MIN(a."createdat_ist") OVER (PARTITION BY a."proposalid"):: date as enrollment_date,
a."proposalid" as kmbl_sys_ref_number,
a."masterpolicyid" as master_policy_number,
a."policystartdate" :: date as policy_issue_date,
a."policyenddate":: date  as policy_expiry_date,
a.crn as crn,
a."grouppolicycode" as Group_product_code,
a."policycategory" as policy_category,
a."source" as channel,
a."autorenewactive",
a."source",
a."referralcode" as sourcing_emp_code,
a."proposalstatus" ,
CASE when a."proposalstatus" = 'FRESH' OR a."proposalstatus" = 'RENEWED' THEN 'TRUE'
ELSE 'FALSE' END as debit_done,
a."paymentId",
a."policyid",
a."masterPolicyId",
a."paymentsuccessfultime":: date as payment_date,
row_number() over(partition by a."proposalid"  order by case when a."updatedat_ist" :: date is not NULL THEN a."updatedat_ist" :: date ELSE '2020-01-01' END  desc) as row_id_proposal
FROM dsg_external.nip_811_kliproposal a),
proposal_tables as (
Select * from CTE_proposal AA
where AA.row_id_proposal = 1
--and datediff('day', AA.enrollment_date :: date, CURRENT_DATE ) <= 60
UNION ALL
Select * from CTE_kliproposal BB
where BB.row_id_proposal = 1
--and datediff('day', BB.enrollment_date :: date, CURRENT_DATE ) <= 60
),
payment_table as (
SELECT      b."paymentId",
                                                b.amount as premium,
                                                b."totalamount" as premium_with_gst,
                                                b."mode" as payment_mode,
                                                b."transactionstatus",
                                                row_number() over(partition by b."paymentId"  order by case when b."updated_at":: date is not NULL THEN b."updated_at":: date ELSE '2020-01-01' END  desc) as row_id_payment
FROM        dsg_external.NIP_811_payment b
),
policy_table as (
SELECT  c."policyname" as product_name,
                                c."policycode" as product_code,
                                c."policytype" as type_of_policy,
                                c."policycode",
                                c."sumassured",
                                row_number() over(partition by c."policycode"  order by case when c."updatedat_ist":: date is not NULL THEN c."updatedat_ist":: date ELSE '2020-01-01' END  desc) as row_id_policy
FROM dsg_external.NIP_811_policy c
),
userdetails_table as (
SELECT      d.crn,
            d.crn_lob as crn_lob,
                                                d.acc_scheme_code,
                                                d.acc_classification,
                                                d.home_branch_code,
                                                d.relationship_type,
                                                row_number() over(partition by d.crn  order by case when d."updatedat_ist":: date is not NULL THEN d."updatedat_ist":: date ELSE '2020-01-01' END  desc) as row_id_userdetails
from dsg_external.NIP_811_userdetails d
),
masterpolicy_table as (
SELECT    e."policycategory" as category,
          e."masterpolicyid",
                                  e."companycode",
                                  row_number() over(partition by e."masterpolicyid" order by case when e."updatedat_ist":: date is not NULL THEN e."updatedat_ist":: date ELSE '2020-01-01' END  desc) as row_id_masterpolicy
FROM  dsg_external.NIP_811_masterpolicy e
)
SELECT
        Prop_1.kmbl_sys_ref_number :: VARCHAR as PROPOSAL_NO,
        pol_tab_1.product_name :: VARCHAR as Product_name,
                                Prop_1.enrollment_date :: date as Enrollment_date,
                                Prop_1.policy_issue_date as Issuance_date,
                                Prop_1.crn as CRN_NUMBER,
                                Prop_1.payment_date :: date as payment_date,
                                pol_tab_1."sumassured" :: FLOAT as sum_assured,
                                null :: date as cancellation_date,
                                pay_tab_1.premium as premium_amount,
                                CASE when pay_tab_1.payment_mode = 'CC' and  lower(Prop_1.debit_done)= 'false' then 'Y' else NULL end                        as ISPOLICYCANCELLED,
                                CASE WHEN master_tab_1.category like '%NON_LIFE%' THEN 'Group_GI_NIP'
                                    WHEN  master_tab_1.category like '%LIFE%' THEN 'Group_LI_NIP'
                                    else NULL END as Insurance_TYPE,
                                 
        CASE WHEN Q.product is not null then Q.product :: VARCHAR
        else 'Self' END as Product,
        Q."flag"  :: VARCHAR as channel,
        case when Q.product = 'Bank' and Q.final_income ~ '^[0-9\.]+$'
        THEN round((Q.final_income :: FLOAT * 0.25) ,2)
        when Q.product = 'Self' and Q.final_income ~ '^[0-9\.]+$'
        THEN round(Q.final_income:: FLOAT ,2)
        ELSE NULL END as Income_share,
        CASE WHEN Prop_1.kmbl_sys_ref_number like '%GI%' THEN 'Total_GI'
        WHEN  Prop_1.kmbl_sys_ref_number like '%LI%' THEN 'Total_LI'
        else NULL END as Insurance_overall_TYPE,
        CASE when Prop_1.kmbl_sys_ref_number like '%R%' THEN 'YES'
        else NULL END as Renewal
from        proposal_tables Prop_1
LEFT JOIN   payment_table pay_tab_1
on          Prop_1."paymentId" = pay_tab_1."paymentId" AND pay_tab_1.row_id_payment = 1
LEFT JOIN   policy_table pol_tab_1
on          Prop_1."policyid" = pol_tab_1."policycode" AND pol_tab_1.row_id_policy = 1
LEFT JOIN   userdetails_table user_tab_1
on          Prop_1."crn" = user_tab_1."crn" AND user_tab_1.row_id_userdetails = 1
LEFT JOIN   masterpolicy_table master_tab_1
on          Prop_1."masterpolicyid" = master_tab_1."masterpolicyid" AND master_tab_1.row_id_masterpolicy = 1
LEFT JOIN dsg_vir_chnl.branch_xsell_group_ins_channel_mapped Q
on  Prop_1.kmbl_sys_ref_number :: VARCHAR  = Q."kmbl_system_reference_no" :: VARCHAR
WHERE datediff('day', Prop_1.enrollment_date :: date, CURRENT_DATE ) <= 365))
select count(distinct CRN_NUMBER) from (
Select DISTINCT  AA.CRN_NUMBER
                                                                
                                                              
FROM insurance AA)


""".format(ref_d6=ref_d6))
gi = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/gi/month={mnthid}/gi_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
gi.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


#####################



####################
# MF


sql = connection.execute("""
   
 
With Cherry as (
SELECT DISTINCT
TO_DATE("transaction date",'YYYY-MM-DD') as tran_date,
a.crn,
"sip registration number" as reg_no,
"instrument or scheme" as scheme,
"transaction mode" as mode,
"freshness flag" as freshness_flag,
"sip start date" as start_date,
"transaction amount" as amt,
"sip cancel date" as cncl_dt,
"order source" source,
row_number() over(partition by "sip registration number"  order by "sip cancel date" ASC) as row_id
FROM kotak811_external.dmart_cherry_sip a
INNER JOIN prod_db.dsg_services.funding_file_monthly b on a.crn = b.crn AND (outward = '' OR outward IS NULL)
      AND report_month = (SELECT MAX(report_month) FROM prod_db.dsg_services.funding_file_monthly)
WHERE "transaction mode" IN ('SIP') AND "freshness flag" IN ('Fresh')
        UNION
SELECT DISTINCT
TO_DATE("transaction date",'YYYY-MM-DD') as tran_date,
a.crn,
"reference number" as reg_no,
"instrument or scheme" as scheme,
"transaction mode" as mode,
"freshness flag" as freshness_flag,
"sip start date" as start_date,
"transaction amount" as amt,
"sip cancel date" as cncl_dt,
"order source" source,
1 as row_id
FROM kotak811_external.dmart_cherry_sip a
INNER JOIN prod_db.dsg_services.funding_file_monthly b on a.crn = b.crn AND (outward = '' OR outward IS NULL)
      AND report_month = (SELECT MAX(report_month) FROM prod_db.dsg_services.funding_file_monthly)
WHERE "transaction mode" IN ('Lumpsum')
        UNION    
SELECT
DISTINCT
TO_date(created_at,'YYYY-MM-DD') as tran_date,
crn_number as crn,
"sip registration number" as reg_no,
scheme_name as scheme,
'SIP' as mode,
'Fresh' as freshness_flag,
start_date as start_date,
sip_amount as amt,
'' as cncl_dt,
"source" source,
row_number() over(partition by "sip registration number"  order by created_at ASC) as row_id
FROM kotak811_external.dmart_cherry_salesforce a
INNER JOIN prod_db.dsg_services.funding_file_monthly b on a.crn_number = b.crn AND (outward = '' OR outward IS NULL)
      AND report_month = (SELECT MAX(report_month) FROM prod_db.dsg_services.funding_file_monthly)
WHERE created_at != 'nan'),
cherry_base as (
SELECT DISTINCT
tran_date,
TO_DATE(tran_date,'YYYY-MM') as tran_month,
a.crn,
reg_no,
mode,
freshness_flag,
scheme,
start_date,
amt,
source,
cncl_dt,
row_number() over(partition by reg_no,a.crn  order by amt DESC) as rowid
FROM Cherry a
WHERE row_id = 1
),
final_cherry as (
SELECT DISTINCT
tran_date,
tran_month,
a.crn,
'Cherry' as Platform,
mode,reg_no,
a.source as order_source,
amt as sip_amt,cncl_dt,
CASE WHEN cncl_dt = 'nan' OR cncl_dt = '' THEN 0 ELSE 1 end as cncl_flag,
CASE WHEN cncl_dt != 'nan' AND cncl_dt != '' AND TO_DATE(cncl_dt, 'YYYY-MM')
          = TO_DATE(CAST(tran_date as date), 'YYYY-MM') THEN 1 ELSE 0 end as same_month_cancelled_sip
FROM cherry_base a
WHERE TO_DATE(CAST(tran_date as date), 'YYYY-MM-DD') >= {ref_d6}
AND rowid = 1
),
mfss as (
WITH mf as (
            select DISTINCT
            REQ_REF_NUM as reg_no,
            a.CRN,
            FOLIO_NUM,
            REQ_TYPE,
            SCHME_CODE,
            SUBSEQUENT_AMT as amt,
            TRAN_CHNNEL,
            CANCLTON_AUTHRZTON_DATE as cncl_dt,
            CASE WHEN CANCLTON_AUTHRZTON_DATE IS NULL THEN 0 ELSE 1 END as cncl_flag,
            TO_DATE(TRAN_REQ_DATE,'YYYY-MM-DD') as tran_date
            from prod_db.dwh_CDR.FCT_TPP_MF_REQUEST a
            INNER JOIN prod_db.dsg_services.funding_file_monthly b on a.crn = b.crn AND (outward = '' OR outward IS NULL)
      AND report_month = (SELECT MAX(report_month) FROM prod_db.dsg_services.funding_file_monthly)
            where
            CURRENT_FLAG = 'Y'
            AND REQ_TYPE ='SIP'
            AND SUBSEQUENT_AMT <= 500000
          ),
base as (
SELECT DISTINCT
reg_no,
CRN,
FOLIO_NUM,
REQ_TYPE,
SCHME_CODE,
amt,
TRAN_CHNNEL,
cncl_dt,
cncl_flag,
tran_date
FROM mf
)
,mfss_sip as (
SELECT DISTINCT
base.reg_no,
base.CRN,
base.FOLIO_NUM,
base.REQ_TYPE,
base.SCHME_CODE,
base.amt,
base.TRAN_CHNNEL,
TO_DATE(base.cncl_dt,'YYYY-MM-DD') as cncl_dt,
base.cncl_flag,
base.tran_date
FROM base
),
base_2 as (
SELECT DISTINCT
TxnID,
b.CRN,
Folio_No,
Transaction_Type,
Product_Cd,
Adjusted_Amount_Purchased,
onlinereqsrctype as tran_channel,
TO_DATE('1900-01-01','YYYY-MM-DD') as cncl_dt,
0 as cncl_flag,
DtTxn
FROM kotak811_external.dmart_mfss_lumpsum a
INNER JOIN prod_db.dsg_services.funding_file_monthly b on split_part(a.crn, '.', 1) = b.crn AND (outward = '' OR outward IS NULL)
      AND report_month = (SELECT MAX(report_month) FROM prod_db.dsg_services.funding_file_monthly)
WHERE Transaction_Type != 'SIP'
)
SELECT DISTINCT
reg_no,
CRN,
amt::varchar AS amt,
TRAN_CHNNEL,
cncl_dt,
tran_date,
'SIP' as mode
FROM mfss_sip
UNION
SELECT DISTINCT
TxnID as reg_no,
CRN as CRN,
Adjusted_Amount_Purchased::varchar as amt,
tran_channel as TRAN_CHNNEL,
cncl_dt,
TO_DATE(DtTxn,'YYYY-MM-DD') as tran_date,
'Lumpsum' as mode
FROM base_2
),
final_mfss as (
SELECT DISTINCT
TO_DATE(CAST(tran_date as date), 'YYYY-MM-DD') as tran_date,
TO_DATE(CAST(tran_date as date), 'YYYY-MM') as tran_month,
a.crn,
'MFSS' as Platform,
mode,
TRAN_CHNNEL as order_source,
reg_no,
amt as sip_amt,
cncl_dt,
CASE WHEN cncl_dt is NOT NULL AND cncl_dt != '1900-01-01' THEN 1 ELSE 0 END AS cncl_flag,
CASE WHEN cncl_dt is NOT NULL AND TO_DATE(cncl_dt, 'YYYY-MM')
          = TO_DATE(CAST(tran_date as date), 'YYYY-MM') THEN 1 ELSE 0 end as same_month_cancelled_sip
FROM mfss a
WHERE TO_DATE(CAST(tran_date as date), 'YYYY-MM-DD') >= {ref_d6}
),
final as (
SELECT DISTINCT
tran_date,
tran_month,
crn,
Platform,
mode,
order_source,
reg_no,
sip_amt,
cncl_flag
FROM final_cherry
    UNION
SELECT DISTINCT
tran_date,
tran_month,
crn,
Platform,
mode,
order_source,
reg_no,
sip_amt,
cncl_flag
FROM final_mfss
)
SELECT DISTINCT
crn 
FROM final a

""".format(ref_d6=ref_d6))
mf = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/mf/month={mnthid}/mf_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
mf.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


#####################




conn.close()
connection.close()
