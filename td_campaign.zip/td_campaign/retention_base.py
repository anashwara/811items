import psycopg2
import shutil
import pandas as pd
import redshift_connector    
from datetime import timedelta
import io
import boto3
import datetime as dt 

from datetime import datetime
import joblib
import numpy as np
import tempfile
import sklearn




# from s3fs.core import S3FileSystem
from datetime import timedelta
pd.set_option('display.float_format', lambda x: '%.3f' % x)

from common_utils.helper import RedshiftUser

session = boto3.Session()

s3 = session.client('s3')

today=dt.date.today()

if today.day <15 :
    mnthid=str(today.year)+"-"+str(today.month)
    last_month = today.replace(day=1) + dt.timedelta(days=-10)

    ref_d1=dt.date.today().replace(day=1) - timedelta(days=1)
    last_mnth=str(last_month.year)+"-"+str(last_month.month)

elif today.day>=15:
    last = today.replace(day=28)
    last_month = last + dt.timedelta(days=10)
    mnthid=str(last_month.year)+"-"+str(last_month.month)
    ref_d1=dt.date.today().replace(day=1) - timedelta(days=45)
    last_mnth=str(last.year)+"-"+str(last.month)



    
ref_d2=ref_d1.replace(day=1) - timedelta(days=1)
ref_d3=ref_d2.replace(day=1) - timedelta(days=1)
ref_d4=ref_d3.replace(day=1) - timedelta(days=1)
ref_d5=ref_d4.replace(day=1) - timedelta(days=1)
ref_d6=ref_d5.replace(day=1) - timedelta(days=1)

login=pd.to_datetime(ref_d4).strftime("%Y-%m-%d")

ref_m1=ref_d1.year*100+ref_d1.month
ref_m2=ref_d2.year*100+ref_d2.month
ref_m3=ref_d3.year*100+ref_d3.month
ref_m4=ref_d4.year*100+ref_d4.month
ref_m5=ref_d5.year*100+ref_d5.month
ref_m6=ref_d6.year*100+ref_d6.month


redshift_username = 'dsg_kmbl227932_anashwara'
redshift_password  = RedshiftUser(redshift_username).get_password().decode("utf-8")

conn = redshift_connector.connect(
     host="prod-de-redshift-cluster.cgjabuq7ccxq.ap-south-1.redshift.amazonaws.com",
     database="prod_db",
     port=5439,
     user=redshift_username,
     password=redshift_password)


connection: redshift_connector.Cursor = conn.cursor()



sql = connection.execute("""
 
 
SELECT 
distinct a.crn, a.accnt_num, initial_depst_amt, a.accnt_opn_date,a.accnt_cls_date, accnt_maturity_date, 
tenor_in_days,online_td_source,intrst_rate,rnwal_date, cast(date_trunc('month', CURRENT_DATE) as date) as reference_mnth
from dsg_portfolio.rel_td_account_details a 
join dsg_services.funding_file_monthly b 
on a.crn=b.crn
where a.prodct_code not like '%RD%' and prodct_code not like '%FF%'
and a.td_cust_clssfcaton_code in ('KSEL','KNOW','KJIFI','K_NOB')
and tenor_in_days >=90
and ((a.accnt_cls_date>=cast(date_trunc('month', CURRENT_DATE) as date)) or (a.accnt_cls_date is null))
and a.accnt_opn_date<cast(date_trunc('month', CURRENT_DATE) as date)

""")
retn_base = pd.DataFrame(sql.fetch_dataframe())
#write data to s3

bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/retention_scoring/month={mnthid}/scoring.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
retn_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

#############


username_mydb = 'dsg_kmbl227932_anashwara'
password_mydb  = RedshiftUser(username_mydb).get_password().decode("utf-8")

connec = redshift_connector.connect(
     host="prod-de-redshift-cluster.cgjabuq7ccxq.ap-south-1.redshift.amazonaws.com",
     database="mydb",
     port=5439,
     user=username_mydb,
     password=password_mydb)

connection_mydb: redshift_connector.Cursor = connec.cursor()



sql = connection_mydb.execute("""
CREATE TABLE if not exists mydb.dsg_portfolio.retention_base ( crn bigint,accnt_num bigint,initial_depst_amt float, accnt_opn_date varchar(256), accnt_cls_date varchar(256),accnt_maturity_date varchar(256), tenor_in_days int, online_td_source varchar(256),intrst_rate float,rnwal_date varchar(256), reference_mnth varchar(256));
""")

sql = connection_mydb.execute("""
 
COPY mydb.dsg_portfolio.retention_base from
's3://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/retention_scoring/month={mnthid}/scoring.csv'
iam_role 'arn:aws:iam::718378052708:role/service-role/AmazonRedshift-CommandsAccessRole-20240513T161101'
CSV IGNOREHEADER 1
""".format(mnthid=mnthid))
# retn_base = pd.DataFrame(sql.fetch_dataframe())
#write data to s3

connection_mydb.close()
connec.close()
###################
### amb

sql = connection.execute("""
 
  with pre_mnth as (
 SELECT crn,reference_mnth,
DATEADD(month, -1, reference_mnth::date) as m1,
DATEADD(month, -2, reference_mnth::date) as m2,
DATEADD(month, -3, reference_mnth::date) as m3,

(( extract(year from m1 ) *100 )+extract(month from  m1)) as my1,
(( extract(year from m2 ) *100 )+extract(month from  m2)) as my2,
(( extract(year from m3 ) *100 )+extract(month from  m3)) as my3

from mydb.dsg_portfolio.retention_base  
)

select 
a.crn,reference_mnth,
sum(case when mnth_year=my1 then amb else null end ) as amb_1,
sum(case when mnth_year=my2 then amb else null end ) as amb_2,
sum(case when mnth_year=my3 then amb else null end ) as amb_3

from pre_mnth a 
left join dsg_portfolio.mom_amb_tall b 
on a.crn=b.crn

and prodct_type='SBA'
group by a.crn,reference_mnth
""")
amb = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/amb/month={mnthid}/amb_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
amb.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



##################
## demogs

sql = connection.execute("""
select distinct a.crn, b.occupation, dob, total_rv,c.first_credit_date,c.first_credit_amt,tier_cate, primary_miss
from mydb.dsg_portfolio.retention_base   a 
join prod_db.dsg_portfolio.base_dashboard_811 b 
on a.crn=b.crn
left join dsg_services.funding_file_monthly c 
on a.crn=c.crn
  where report_month =(select max(report_month) from prod_db.dsg_services.funding_file_monthly)
  and month=(select max(month) from prod_db.dsg_portfolio.base_dashboard_811 )
""")
demogs = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/demogs/month={mnthid}/demogs_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
demogs.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


###############################
# mb
sql = connection.execute("""
select distinct b.crn,reference_mnth,
sum(case when (reference_mnth::date - cast(login_time as date)) <=30 then 1 else 0 end ) as login_1m,
sum(case when ((reference_mnth::date - cast(login_time as date) <=60) and (reference_mnth::date - cast(login_time as date) >30)) then 1 else 0 end ) as login_2m,

sum(case when ((reference_mnth::date - cast(login_time as date) <=90) and (reference_mnth::date - cast(login_time as date) >60)) then 1 else 0 end ) as login_3m
from 

dwh_dmrt.uc5_convenience_report_details_login a
join mydb.dsg_portfolio.retention_base  b 
on a.crn=b.crn
where reference_mnth::date - cast(login_time as date) <=90
group by b.crn,reference_mnth """)
mb = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/mb/month={mnthid}/mb_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
mb.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



################################



###############################
# tran
sql = connection.execute("""
with pre_mnth as (
 SELECT crn,reference_mnth,
DATEADD(month, -1, reference_mnth::date) as m1,
DATEADD(month, -2, reference_mnth::date) as m2,
DATEADD(month, -3, reference_mnth::date) as m3,

(( extract(year from m1 ) *100 )+extract(month from  m1)) as my1,
(( extract(year from m2 ) *100 )+extract(month from  m2)) as my2,
(( extract(year from m3 ) *100 )+extract(month from  m3)) as my3


from mydb.dsg_portfolio.retention_base 
)

select a.crn,reference_mnth,
sum(case when monthid=my1 then cr_cnt else null end ) as cr_cnt_1,
sum(case when monthid=my2 then cr_cnt else null end ) as cr_cnt_2,
sum(case when monthid=my3 then cr_cnt else null end ) as cr_cnt_3,


sum(case when monthid=my1 then cr_amt else null end ) as cr_amt_1,
sum(case when monthid=my2 then cr_amt else null end ) as cr_amt_2,
sum(case when monthid=my3 then cr_amt else null end ) as cr_amt_3,


sum(case when monthid=my1 then dr_cnt else null end ) as dr_cnt_1,
sum(case when monthid=my2 then dr_cnt else null end ) as dr_cnt_2,
sum(case when monthid=my3 then dr_cnt else null end ) as dr_cnt_3,


sum(case when monthid=my1 then dr_amt else null end ) as dr_amt_1,
sum(case when monthid=my2 then dr_amt else null end ) as dr_amt_2,
sum(case when monthid=my3 then dr_amt else null end ) as dr_amt_3

from pre_mnth a 
left join dsg_portfolio.mom_tran_crdr b 
on a.crn=b.crn
group by a.crn,reference_mnth
 """)
crdr = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/crdr/month={mnthid}/crdr_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
crdr.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



################################


################################

retn_base=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/retention_scoring/month={mnthid}/scoring.csv'.format(mnthid=mnthid))
amb=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/amb/month={mnthid}/amb_{mnthid}.csv'.format(mnthid=mnthid))
demogs=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/demogs/month={mnthid}/demogs_{mnthid}.csv'.format(mnthid=mnthid))
crdr=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/crdr/month={mnthid}/crdr_{mnthid}.csv'.format(mnthid=mnthid))
mb=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/mb/month={mnthid}/mb_{mnthid}.csv'.format(mnthid=mnthid))



cls_ads=pd.merge(retn_base,amb,on=['crn','reference_mnth'],how='left')
cls_ads=pd.merge(cls_ads,crdr,on=['crn','reference_mnth'],how='left')
demogs=demogs.drop_duplicates()
cls_ads=pd.merge(cls_ads,demogs,on='crn',how='left')
mb=mb.drop_duplicates()
cls_ads=pd.merge(cls_ads,mb,on=['crn','reference_mnth'],how='left')

cls_ads['accnt_cls_date']=pd.to_datetime(cls_ads['accnt_cls_date'])

cls_ads['reference_mnth']=pd.to_datetime(cls_ads['reference_mnth'])
cls_ads['accnt_opn_date']=pd.to_datetime(cls_ads['accnt_opn_date'])
cls_ads['accnt_cls_date']=pd.to_datetime(cls_ads['accnt_cls_date'])
cls_ads['accnt_maturity_date']=pd.to_datetime(cls_ads['accnt_maturity_date'])
cls_ads['rnwal_date']=pd.to_datetime(cls_ads['rnwal_date'])
cls_ads['first_credit_date']=pd.to_datetime(cls_ads['first_credit_date'])
cls_ads['dob']=pd.to_datetime(cls_ads['dob'])


model_path="811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/model_files/"
bucket_name='kotak-811-cdp-peak-write'


with tempfile.TemporaryFile() as fp:
    s3.download_fileobj(Fileobj=fp, Bucket=bucket_name, Key=model_path+"rf_model_1.pkl")
    fp.seek(0)
    rf_model = joblib.load(fp)


cls_ads['fd_age']=(cls_ads['reference_mnth']-cls_ads['accnt_opn_date']).dt.days 
cls_ads['fd_age_tenure']=cls_ads['fd_age']/cls_ads['tenor_in_days'] # 
cls_ads['rnwal_flag']=np.where(cls_ads['rnwal_date'].isna(),0,1)
cls_ads['cr_dr_amt_1m']=cls_ads['cr_amt_1']/cls_ads['dr_amt_1']

cls_ads['cr_dr_amt_2m']=cls_ads['cr_amt_2']/cls_ads['dr_amt_2']
cls_ads['cr_dr_amt_3m']=cls_ads['cr_amt_3']/cls_ads['dr_amt_3']
cls_ads['cr_dr_amt_1m_3m']=cls_ads['cr_dr_amt_1m']/cls_ads['cr_dr_amt_3m']
cls_ads['cr_amt_1m_3m']=cls_ads['cr_amt_1']/cls_ads['cr_amt_3']
cls_ads['dr_amt_1m_3m']=cls_ads['dr_amt_1']/cls_ads['dr_amt_3']
cls_ads['amb_1m_3m']=cls_ads['amb_1']/cls_ads['amb_3']
cls_ads['primary_flag']=np.where(cls_ads['primary_miss']=='PRIMARY', 1,0)

cls_ads['age']=(cls_ads['reference_mnth']-cls_ads['dob']).dt.days/365

cls_ads['occupation']=cls_ads['occupation'].replace({'Service - Private Sector':'Salaried',
    'Professional':'Salaried','Service - Public Sector':'Salaried',
    'Service - Government Sector':'Salaried','Self Employees Professional (SEP)':'Self Employed',
     'SENP - Job Worker':'Self Employed', 
       'Self Employees Professional (SEP)':'Self Employed', 'SENP - Retail Trader':'Self Employed',
       'SENP - Others':'Self Employed', 
                   'SENP - Dealership':'Self Employed',                                  
                                                     'SENP - Wholesale Trader':'Self Employed',
       'SENP - Service Industry':'Self Employed', 'Self Employed Non Professional':'Self Employed',
       'SENP - Distributor':'Self Employed', 'SENP - Manufacturer':'Self Employed','Business':  'Self Employed',
                                    'Non Working':'Others'                
    })

cls_ads['occupation']=cls_ads['occupation'].fillna('Others')

def one_hot(df, cols,drop_og_variable=False):
    """
    df:pandas DataFrame
    cols: a list of columns to encode 
    return a DataFrame with one-hot encoding
    """
    for each in cols:
        dummies = pd.get_dummies(df[each], prefix=each, drop_first=drop_og_variable)
        dummies.replace({True:'1',False:'0'},inplace=True)
        df = pd.concat([df, dummies], axis=1)
    df.drop(cols,axis=1,inplace=True)
    return df
cols=['tier_cate']
# cols=['occupation','tier_cate']
cls_ads=one_hot(cls_ads,cols,True)

base=cls_ads[['crn','initial_depst_amt','reference_mnth','accnt_num','fd_age','fd_age_tenure','tenor_in_days','intrst_rate','amb_1', 'amb_2', 'amb_3', 'cr_cnt_1',
       'cr_cnt_2', 'cr_cnt_3', 'cr_amt_1', 'cr_amt_2', 'cr_amt_3', 'dr_cnt_1',
       'dr_cnt_2', 'dr_cnt_3', 'dr_amt_1', 'dr_amt_2', 'dr_amt_3','cr_dr_amt_1m','cr_dr_amt_2m','cr_dr_amt_3m','cr_dr_amt_1m_3m',
'cr_amt_1m_3m','dr_amt_1m_3m','amb_1m_3m','primary_flag','tier_cate_b) Tier_2', 'tier_cate_c) Tier_3','first_credit_amt','age']]


base['age'].fillna(base['age'].mean(),inplace=True)
base.fillna(0,inplace=True)
base.replace([np.inf, -np.inf], np.nan, inplace=True)
base.fillna(0, inplace=True)

base = base.reset_index(drop=True)

x=base.drop(['crn','reference_mnth','accnt_num','initial_depst_amt'],axis=1)

# y=base[['crn','target','initial_depst_amt']]

pred=rf_model.predict(x)

base['pred_proba']=rf_model.predict_proba(x)[:,1]

base['decile']=10-pd.qcut(base['pred_proba'], 10, labels = False)

pred_base=base[['crn','pred_proba','decile']]

cls_crn=retn_base[(~retn_base.accnt_cls_date.isna())]['crn'].unique()

pred_base[(pred_base['decile']<6)&(pred_base['crn'].isin(cls_crn))]['crn'].nunique()

crn_output=retn_base[(retn_base['crn'].isin(pred_base.crn))&(~retn_base.crn.isin(cls_crn))].groupby('crn').agg(fd_count=('accnt_num', 'count'),
            oldest_fd_date=('accnt_opn_date','min'),newest_fd_date=('accnt_opn_date','max'),
            total_amt=('initial_depst_amt','sum') )

pred_base=pred_base.sort_values('decile').drop_duplicates('crn',keep='first').reset_index(drop=True)

cls_predicted_base=pd.merge(pred_base,crn_output,on='crn',how='inner')
cls_predicted_base=cls_predicted_base[cls_predicted_base.decile<=7]

cls_predicted_base['priority']=pd.cut(cls_predicted_base['decile'],bins=[0,2,4,8],labels=['H','M','L'])


#################
# cls base 

cls=retn_base[(~retn_base.accnt_cls_date.isna())]

cls['accnt_cls_date']=pd.to_datetime(cls['accnt_cls_date'])
cls['accnt_opn_date']=pd.to_datetime(cls['accnt_opn_date'])

cls=cls[(cls['accnt_cls_date']-cls['accnt_opn_date']).dt.days>30]

cls_base=cls.groupby('crn').agg(fd_count=('accnt_num', 'count'),
            oldest_fd_date=('accnt_opn_date','min'),newest_fd_date=('accnt_opn_date','max'),
            total_amt=('initial_depst_amt','sum') ).reset_index()


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/cls_base/month={mnthid}/cls_base_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
cls_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

####################


# maturity
sql = connection.execute("""
with latest_date as (
select a.accnt_id,max(a.etl_updated_date) as etl_updated_date 
from dwh_cdr.dim_term_deposit_account a 
join  dsg_portfolio.rel_td_account_details c 
on a.accnt_num=c.accnt_num
where a.current_flag='Y'
and a.accnt_cls_date is null
and a.schme_code not like '%FF%'
and a.schme_code not like '%RD%'
group by a.accnt_id
)
select distinct c.crn,a.accnt_num,a.auto_rnwal_flag as cdr_rnwalflag,a.rnwal_date  as cdr_rnwal_date,
c.auto_rnwal_flag as rel_rnwal_flag,
c.rnwal_date as rel_rnwal_date ,c.initial_depst_amt as rel_amt,a.initial_depst_amt as cdr_amt,
c.accnt_maturity_date as rel_maturity,a.accnt_maturity_date as cdr_maturity
from dwh_cdr.dim_term_deposit_account a 
join 
latest_date b 
on a.accnt_id=b.accnt_id
and a.etl_updated_date=b.etl_updated_date 
join dsg_portfolio.rel_td_account_details c 
on a.accnt_num=c.accnt_num
where 
c.accnt_maturity_date<(current_date+45)
and c.accnt_maturity_date>current_date
and c.accnt_cls_date is null
and c.prodct_code not like '%RD%' and prodct_code not like '%FF%'
and c.td_cust_clssfcaton_code in ('KSEL','KNOW','KJIFI','K_NOB')
and c.tenor_in_days >=90
 """)
mat = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/maturity/month={mnthid}/maturity_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
mat.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

mat['crn']=mat['crn'].astype(int)

mat['base_name']=np.where(mat['cdr_rnwalflag']=='N','Maturity_non_renewed',None)
mat['base_name']=np.where((mat['cdr_rnwalflag']=='U')&(mat['crn'].isin(cls_predicted_base.crn)),'Maturity_renewed',mat['base_name'])

mat=mat[~mat['base_name'].isna()]
mat_gp_1=mat[mat['base_name']=='Maturity_non_renewed'].groupby('crn').agg(fd_count=('accnt_num', 'count'),
            first_maturity_date=('rel_maturity','min'),last_maturity_date=('rel_maturity','max'),
                                                                          base_name=('base_name','max'),
            total_amt=('cdr_amt','sum') ).reset_index()

mat_gp_2=mat[mat['base_name']=='Maturity_renewed'].groupby('crn').agg(fd_count=('accnt_num', 'count'),
            first_maturity_date=('rel_maturity','min'),last_maturity_date=('rel_maturity','max'),
                                                                          base_name=('base_name','max'),
            total_amt=('cdr_amt','sum') ).reset_index()

mat_gp=pd.concat([mat_gp_1,mat_gp_2],axis=0)
#dedupe 2 maturities- prioritise non renewal
mat_gp=mat_gp.drop_duplicates('crn',keep='first')
mat_gp=pd.merge(mat_gp,cls_predicted_base[cls_predicted_base['crn'].isin(mat_gp.crn)][['crn','decile']],on='crn',how='left')


cls_predicted_base=cls_predicted_base[~cls_predicted_base['crn'].isin(mat_gp.crn)]
cls_predicted_base['base_name']='Propensity_base'
cls_base['base_name']='Closed FD'
ret_base=pd.concat([cls_predicted_base,cls_base,mat_gp],axis=0)




bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/intermediate/inter_file.csv'

buffer = io.BytesIO()
ret_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


########### create table 
host = "prod-de-redshift-cluster.cgjabuq7ccxq.ap-south-1.redshift.amazonaws.com"
port = "5439"
db = "mydb"
redshift_username = 'dsg_kmbl227932_anashwara'
redshift_password  = RedshiftUser(redshift_username).get_password().decode("utf-8")

# username = "dsg_kmbl327599_arion"
# password = "n#MWf6LY" # password for redshift
uri = f"postgresql://{redshift_username}:{redshift_password}@{host}:{port}/{db}"
 
 
con=psycopg2.connect(uri)
con.autocommit = True
cursor = con.cursor()
 
create_query='CREATE TABLE if not exists mydb.dsg_portfolio.td_retention_campaign_base(crn varchar,pred_proba varchar,decile varchar,fd_count varchar,oldest_fd_date varchar,newest_fd_date varchar,total_amt float8,priority varchar,base_name varchar,first_maturity_date varchar,last_maturity_date varchar);'
copy_query="""
COPY mydb.dsg_portfolio.td_retention_campaign_base from
's3://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/intermediate/inter_file.csv'
iam_role 'arn:aws:iam::718378052708:role/service-role/AmazonRedshift-CommandsAccessRole-20240513T161101'
CSV IGNOREHEADER 1"""
cursor.execute(create_query)
cursor.execute(copy_query)

con.close()

########################################
sql = connection.execute("""
 
select distinct b.* from mydb.dsg_portfolio.td_retention_campaign_base b

    join   
      prod_db.dsg_services.funding_file_monthly a
        on a.crn = b.crn
      
    where
     current_schme_code in ('LSJIFN','LSDIGI','SJIFN','SDIGI')   
and cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
and accnt_cls_flag='N'
and accnt_status ='A'
and report_month =(select max(report_month) from dsg_services.funding_file_monthly)

""")
retn_811_base = pd.DataFrame(sql.fetch_dataframe())
#write data to s3

bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/retention_scoring/first_base.csv'

buffer = io.BytesIO()
retn_811_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


old_control=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/retention_scoring/control_base.csv')


continued_control=old_control[old_control['crn'].isin(retn_811_base.crn)]


prev_base=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/cvm_base/month={last_mnth}/retention_base_cvm_{last_mnth}.csv'.format(last_mnth=last_mnth))

prop_cnt=8289-continued_control[continued_control.base_name=='Propensity_base'].shape[0]
mat_ren_cnt=1047-continued_control[continued_control.base_name=='Maturity_renewed'].shape[0]
mat_nonren_cnt=500-continued_control[continued_control.base_name=='Maturity_non_renewed'].shape[0]
cls_cnt=500-continued_control[continued_control.base_name=='Closed FD'].shape[0]

new_control=pd.DataFrame()
if prop_cnt>0:
    prop=retn_811_base[retn_811_base['base_name']=='Propensity_base']
    nc=prop[~(prop['crn'].isin(continued_control.crn))&(~(prop['crn'].isin(prev_base.crn)))].sample(prop_cnt)
    nc['base_name']='Propensity_base'
    new_control=pd.concat([new_control,nc],axis=0)
    
if mat_ren_cnt>0:
    prop=retn_811_base[retn_811_base['base_name']=='Maturity_renewed']
    nc=prop[~(prop['crn'].isin(continued_control.crn))&(~(prop['crn'].isin(prev_base.crn)))].sample(mat_ren_cnt)
    nc['base_name']='Maturity_renewed'
    new_control=pd.concat([new_control,nc],axis=0)

if mat_nonren_cnt>0:
    prop=retn_811_base[retn_811_base['base_name']=='Maturity_non_renewed']
    nc=prop[~(prop['crn'].isin(continued_control.crn))&(~(prop['crn'].isin(prev_base.crn)))].sample(mat_nonren_cnt)
    nc['base_name']='Maturity_non_renewed'
    new_control=pd.concat([new_control,nc],axis=0)

if cls_cnt>0:
    prop=retn_811_base[retn_811_base['base_name']=='Closed FD']
    nc=prop[~(prop['crn'].isin(continued_control.crn))&(~(prop['crn'].isin(prev_base.crn)))].sample(cls_cnt)
    nc['base_name']='Closed FD'
    new_control=pd.concat([new_control,nc],axis=0)
    

control=pd.concat([continued_control,new_control],axis=0)



retn_811_base['priority']=(retn_811_base['total_amt'].rank(method = 'min') -1) / (retn_811_base['total_amt'].count() - 1)

retn_811_base['decile']=np.where(retn_811_base.decile.isna(),(10-pd.qcut(retn_811_base['priority'].rank(method='first'), 10, labels = False)),retn_811_base['decile'])




bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/cvm_base/month={mnthid}/retention_base_cvm_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
retn_811_base[~retn_811_base['crn'].isin(control.crn)].to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/retention/retention/retention_scoring/control_base.csv'

buffer = io.BytesIO()
control.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


