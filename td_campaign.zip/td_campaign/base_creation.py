import psycopg2
import shutil
import pandas as pd
import datetime
import redshift_connector    
from datetime import timedelta
import io
import boto3
import numpy as np



# from s3fs.core import S3FileSystem
from datetime import timedelta
pd.set_option('display.float_format', lambda x: '%.3f' % x)


session = boto3.Session()

s3 = session.client('s3')

today=dt.date.today()

if today.day <15 :
    mnthid=str(today.year)+"-"+str(today.month)
    last_month = today.replace(day=1) + dt.timedelta(days=-10)

    ref_d1=dt.date.today().replace(day=1) - timedelta(days=1)
    last_mnth=str(last_month.year)+"-"+str(last_month.month)

elif today.day>=15:
    last = today.replace(day=28)
    last_month = last + dt.timedelta(days=10)
    mnthid=str(last_month.year)+"-"+str(last_month.month)
    ref_d1=dt.date.today().replace(day=1) - timedelta(days=45)
    last_mnth=str(last.year)+"-"+str(last.month)



    
ref_d2=ref_d1.replace(day=1) - timedelta(days=1)
ref_d3=ref_d2.replace(day=1) - timedelta(days=1)
ref_d4=ref_d3.replace(day=1) - timedelta(days=1)
ref_d5=ref_d4.replace(day=1) - timedelta(days=1)
ref_d6=ref_d5.replace(day=1) - timedelta(days=1)

login=pd.to_datetime(ref_d4).strftime("%Y-%m-%d")

ref_m1=ref_d1.year*100+ref_d1.month
ref_m2=ref_d2.year*100+ref_d2.month
ref_m3=ref_d3.year*100+ref_d3.month
ref_m4=ref_d4.year*100+ref_d4.month
ref_m5=ref_d5.year*100+ref_d5.month
ref_m6=ref_d6.year*100+ref_d6.month



base_811=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/base_811/month={mnthid}/base_811.csv'.format(mnthid=mnthid))

gold=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/gold_base/month={mnthid}/gold_base_{mnthid}.csv'.format(mnthid=mnthid))

mat=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/loan_maturity/month={mnthid}/loan_maturity_{mnthid}.csv'.format(mnthid=mnthid))

brand=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/811brand/month={mnthid}/811brand_{mnthid}.csv'.format(mnthid=mnthid))

#### salary base not getting updated hence using old base
salary_acc=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/salary_base/Salary_base_oct.csv')

salary_acc=salary_acc.drop("Unnamed: 0",axis=1)
##########

ntb=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/ntb/month={mnthid}/ntb_{mnthid}.csv'.format(mnthid=mnthid))
ntb['priority']=(ntb["measure"].rank(method="min") ) -1
ntb['priority']=(ntb['priority'].rank(method = 'min') -1) / (ntb['priority'].count() - 1)


fd_eu=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_eu/month={mnthid}/fd_eu_{mnthid}.csv'.format(mnthid=mnthid))

### CV not getting updated hence using old bases
fd_cv=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/External_funds/cv_base/crn_fd_202410.csv')
# fd_cv=fd_cv.drop("Unnamed: 0",axis=1)

fd_cv['base_name']='fd_external_funds'
rd_cv=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/External_funds/cv_base/crn_rd_202410.csv')

rd_cv['base_name']='rd_external_funds'
fd_cv=fd_cv[~(fd_cv['base_name']=='rd_external_funds')]

######


fd_nu_prop=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/fd_nu/full_base/month={mnthid}/fullbase_{mnthid}.csv'.format(mnthid=mnthid))

rd_prop=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/full_base/month={mnthid}/rd_nu_base_{mnthid}.csv'.format(mnthid=mnthid))

am=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/activmoney/month={mnthid}/activmoney_{mnthid}.csv'.format(mnthid=mnthid))
am['priority']=(am["amb"].rank(method="min") ) -1
am['priority']=(am['priority'].rank(method = 'min') -1) / (am['priority'].count() - 1)


mf=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/mf/month={mnthid}/mf_{mnthid}.csv'.format(mnthid=mnthid))
kra=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/kra/month={mnthid}/kra_{mnthid}.csv'.format(mnthid=mnthid))

tm=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/travel_medical/month={mnthid}/travel_medical_{mnthid}.csv'.format(mnthid=mnthid))


gi=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/gi/month={mnthid}/gi_{mnthid}.csv'.format(mnthid=mnthid))


whole_control=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/control/whole_control_sep_3camp_added.csv')

salary_acc_rd=salary_acc[salary_acc['fd_rd']=='RD']
salary_acc_fd=salary_acc[salary_acc['fd_rd']=='FD']




brand['base_name']='811brand'
brand['priority']=(brand['amb'].rank(method = 'min') -1) / (brand['amb'].count() - 1)
brand['decile']=10-pd.qcut(brand['amb'].rank(method='first'), 10, labels = False)

salary_acc_rd['base_name']='RD salary base'
salary_acc_rd['priority']=(salary_acc_rd['avg'].rank(method = 'min') -1) / (salary_acc_rd['avg'].count() - 1)
salary_acc_rd['decile']=10-pd.qcut(salary_acc_rd['avg'].rank(method='first'), 10, labels = False)


salary_acc_fd['base_name']='FD salary base'
salary_acc_fd['priority']=(salary_acc_fd['avg'].rank(method = 'min') -1) / (salary_acc_fd['avg'].count() - 1)
salary_acc_fd['decile']=10-pd.qcut(salary_acc_fd['avg'].rank(method='first'), 10, labels = False)


gold['base_name']='Gold'
gold['priority']=(gold['tran_amt'].rank(method = 'min') -1) / (gold['tran_amt'].count() - 1)
gold['decile']=10-pd.qcut(gold['tran_amt'].rank(method='first'), 10, labels = False)


mat['base_name']='Loan Maturity'
mat['priority']=(mat['predicted_emi'].rank(method = 'min') -1) / (mat['predicted_emi'].count() - 1)
mat['decile']=10-pd.qcut(mat['predicted_emi'].rank(method='first'), 10, labels = False)


ntb['base_name']='NTB'
# ntb['priority']=ntb['priority'].rank(method = 'min',ascending=False) /(ntb['priority'].count() )
# ntb['persona']=ntb['Age_segment']
ntb['decile']=pd.qcut(ntb['priority'].rank(method='first'), 10, labels = False)



# ntb['persona']=ntb['Age_segment'].str.replace('Younger','Spender')

# ntb['persona']=ntb['persona'].str.replace('Mid- Old','Saver')

# fd_eu['base_name']='FD EU'
fd_eu['base_name']=np.where(fd_eu['fd_live']=='inactive','FD EU Inactive','FD EU Active')
fd_eu['priority'].fillna(100,inplace=True)
fd_eu['priority']=(100-fd_eu['priority'])/100



# fd_eu['persona']=fd_eu[['spender_priority','saver_priority']].idxmin(skipna=True,axis=1)
# fd_eu['persona']=np.where((fd_eu['persona'].isna() & fd_eu['investor']==1) , 'investor_priority',fd_eu['persona'])
# fd_eu['persona']=np.where(fd_eu['persona'].isna()  , 'Others',fd_eu['persona'])
fd_eu['decile']=10-pd.qcut(fd_eu['priority'].rank(method='first'), 10, labels = False)



# self['base_name']='FD NU'
# self['persona']='Self fund transfer'

# self['priority']=(self['amb_202409'].rank(method = 'min') -1) / (self['amb_202409'].count() - 1)

# self['decile']=10-pd.qcut(self['priority'].rank(method='first'), 10, labels = False)



fd_nu_prop['base_name']='FD NU'
fd_nu_prop.rename(columns={'y_pred_proba':'priority'},inplace=True)

fd_cv['base_name']='FD NU'
fd_cv['persona']='External_funds'
fd_cv['priority']=(fd_cv['data.customer360.data.bankaccount.aggregateaveragemonthlybalance'].rank(method = 'min') -1) / (fd_cv['data.customer360.data.bankaccount.aggregateaveragemonthlybalance'].count() - 1)
fd_cv['decile']=10-pd.qcut(fd_cv['priority'].rank(method='first'), 10, labels = False)




am['base_name']='Activmoney'
am['priority'].fillna(100,inplace=True)
am['priority']=(100-am['priority'])/100
am['decile']=10-pd.qcut(am['priority'].rank(method='first'), 10, labels = False)



rd_cv['base_name']='RD'
rd_cv['priority']=(rd_cv['data.customer360.data.bankaccount.aggregateaveragemonthlybalance'].rank(method = 'min') -1) / (rd_cv['data.customer360.data.bankaccount.aggregateaveragemonthlybalance'].count() - 1)
rd_cv['decile']=10-pd.qcut(rd_cv['priority'].rank(method='first'), 10, labels = False)



rd_prop['base_name']='RD'
rd_prop.rename(columns={'y_pred_proba':'priority'},inplace=True)
# rd_prop['decile']=10-pd.qcut(rd_prop['priority'].rank(method='first'), 10, labels = False)


rd_prop['basetype']='RD propensity'
# rd_nonlive['basetype']='RD nonlive'
# rd_cv['basetype']='RD CV'

mf['base']='MF'
gi['priority']=1
gi['base']='GI'
mf['priority']=1
kra['priority']=.5
kra['base']='KRA'
tm['base']='Travel_medical'

mf_kra_gi_tm=pd.concat([mf,kra,gi,tm],axis=0)

mf_kra_gi_tm['decile']=mf_kra_gi_tm['priority']
mf_kra_gi_tm['priority']=1- ((mf_kra_gi_tm['priority'].rank(method = 'min') -1) / (mf_kra_gi_tm['priority'].count() -1))
mf_kra_gi_tm['base_name']=mf_kra_gi_tm['base']

mf_gi_tm=mf_kra_gi_tm[mf_kra_gi_tm['base_name']!='KRA']
kra=mf_kra_gi_tm[mf_kra_gi_tm['base_name']=='KRA']



base=pd.concat([
    fd_eu,
    brand, gold,
    mat,
    mf_gi_tm,
    salary_acc_fd,
    ntb,
    salary_acc_rd,
    fd_cv,
    kra,
    fd_nu_prop,     
    am,
    rd_cv,
    rd_prop
                      
],axis=0).reset_index(drop=True).drop_duplicates('crn')

base=base[~base['crn'].isin(whole_control.crn)]

base=base[base['crn'].isin(base_811.crn)]

base['crn']=base['crn'].astype('int').astype('str')



bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/final_campaign_bases/full_base/monthid={mnthid}/full_base_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
base[['crn', 'tran_amt', 'priority', 'base_name', 'predicted_emi', 
       'decile',
       'persona',
       'basetype']].to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/final_campaign_bases/cvm/monthid={mnthid}/cvm_base_{mnthid}.csv'.format(mnthid=mnthid)
buffer = io.BytesIO()
base[['crn','priority','base_name','decile','persona']].to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



