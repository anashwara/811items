import psycopg2
import shutil
import pandas as pd
import redshift_connector    
from datetime import timedelta
import io
import boto3
import datetime as dt 

from datetime import datetime
import joblib
import numpy as np
import tempfile
import sklearn




# from s3fs.core import S3FileSystem
from datetime import timedelta
pd.set_option('display.float_format', lambda x: '%.3f' % x)

from common_utils.helper import RedshiftUser

session = boto3.Session()

s3 = session.client('s3')

today=dt.date.today()

if today.day <15 :
    mnthid=str(today.year)+"-"+str(today.month)
    last_month = today.replace(day=1) + dt.timedelta(days=-10)

    ref_d1=dt.date.today().replace(day=1) - timedelta(days=1)
    last_mnth=str(last_month.year)+"-"+str(last_month.month)

elif today.day>=15:
    last = today.replace(day=28)
    last_month = last + dt.timedelta(days=10)
    mnthid=str(last_month.year)+"-"+str(last_month.month)
    ref_d1=dt.date.today().replace(day=1) - timedelta(days=45)
    last_mnth=str(last.year)+"-"+str(last.month)



    
ref_d2=ref_d1.replace(day=1) - timedelta(days=1)
ref_d3=ref_d2.replace(day=1) - timedelta(days=1)
ref_d4=ref_d3.replace(day=1) - timedelta(days=1)
ref_d5=ref_d4.replace(day=1) - timedelta(days=1)
ref_d6=ref_d5.replace(day=1) - timedelta(days=1)

login=pd.to_datetime(ref_d4).strftime("%Y-%m-%d")

ref_m1=ref_d1.year*100+ref_d1.month
ref_m2=ref_d2.year*100+ref_d2.month
ref_m3=ref_d3.year*100+ref_d3.month
ref_m4=ref_d4.year*100+ref_d4.month
ref_m5=ref_d5.year*100+ref_d5.month
ref_m6=ref_d6.year*100+ref_d6.month


redshift_username = 'dsg_kmbl227932_anashwara'
redshift_password  = RedshiftUser(redshift_username).get_password().decode("utf-8")

conn = redshift_connector.connect(
     host="prod-de-redshift-cluster.cgjabuq7ccxq.ap-south-1.redshift.amazonaws.com",
     database="prod_db",
     port=5439,
     user=redshift_username,
     password=redshift_password)


connection: redshift_connector.Cursor = conn.cursor()



sql = connection.execute("""
  with
  saving as (
select accnt_num,max(crn) as crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_saving_account
    where current_flag='Y'
    group by accnt_num   
),
saving_crn as (
select distinct a.crn, a.accnt_num
from dwh_cdr.dim_saving_account a 
join saving b
 on a.accnt_num=b.accnt_num
    and a.etl_updated_date=b.etl_updated_date
    and accnt_cls_flag='N'
    and current_flag='Y'
and accnt_status ='A' 
),
indiv as (

select crn, max(etl_updated_date) as etl_updated_date
    from dwh_cdr.dim_individual_customer
    where current_flag='Y'
    group by crn   
),
indiv_crn as (
select distinct a.crn,cust_clssfcaton_code
    from dwh_cdr.dim_individual_customer a 
join indiv b
 on a.crn=b.crn
    and a.etl_updated_date=b.etl_updated_date
    where cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
    and current_flag='Y'
),

crns as (
select distinct  a.crn
from saving_crn a 
join indiv_crn b 
on a.crn=b.crn

), 
  crdr as 
  (select crn,
 sum( case when month_year ={ref_m1} then cr_cnt else 0 end) as m1_cnt,
 sum( case when month_year ={ref_m2} then cr_cnt else 0 end) as m2_cnt,
 sum( case when month_year ={ref_m3} then cr_cnt else 0 end) as m3_cnt,
 sum( case when month_year ={ref_m4} then cr_cnt else 0 end) as m4_cnt,
 sum( case when month_year ={ref_m5} then cr_cnt else 0 end) as m5_cnt
 from dsg_portfolio.mom_tran_crdr 
  where month_year in ({ref_m1}, {ref_m2},{ref_m3},{ref_m4},{ref_m5})
  group by crn 
  having ( ((m1_cnt+m2_cnt+m3_cnt+m4_cnt+m5_cnt)>0 ) )
  --(m1_cnt>0 ) or (m2_cnt>0 ) or
  ),
  target_1 as (
    select
      a.crn,
      a.accnt_opn_date,open_schme_code,current_schme_code, 
      case when open_schme_code in ('LSJIFL','LSJIFW','SJIFW','SJIFL') 
      then  fkyc_date else accnt_opn_date end as fkyc_date 
    from
      prod_db.dsg_services.funding_file_monthly a   
    where
      cast(accnt_opn_date as date) >= '2020-03-01'
      and cast(accnt_opn_date as date) <= '{refdate}'
      and report_month =(select max(report_month) from dsg_services.funding_file_monthly)
and current_schme_code in ('LSJIFN','LSDIGI','SJIFN','SDIGI')  
and cust_clssfcaton_code in ('KNOW','KJIFI','KSEL','K_NOB')
and accnt_cls_flag='N'
and a.crn not in (
        select
          crn
        from
          dsg_portfolio.rel_td_account_details
        where
          prodct_code like '%RD%'
            )
  )
select distinct a.crn, accnt_opn_date,open_schme_code,current_schme_code, fkyc_date
from
  target_1 a 
 join crdr b 
  on cast(a.crn as bigint)=cast(b.crn as bigint)
  join crns c 
  on a.crn=c.crn
""".format(refdate=ref_d3,ref_m1=ref_m1,ref_m2=ref_m2,ref_m3=ref_m3,ref_m4=ref_m4,ref_m5=ref_m5))
scoring_base = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/rd_nu_scoring_live/scoring.csv'

buffer = io.BytesIO()
scoring_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/rd_scoring/month={mnthid}/scoring_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
scoring_base.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




########### create table 


host = "prod-de-redshift-cluster.cgjabuq7ccxq.ap-south-1.redshift.amazonaws.com"
port = "5439"
db = "mydb"
redshift_username = 'dsg_kmbl227932_anashwara'
redshift_password  = RedshiftUser(redshift_username).get_password().decode("utf-8")

# username = "dsg_kmbl327599_arion"
# password = "n#MWf6LY" # password for redshift
uri = f"postgresql://{redshift_username}:{redshift_password}@{host}:{port}/{db}"
 
 
con=psycopg2.connect(uri)
con.autocommit = True
cursor = con.cursor()
 
create_query='CREATE TABLE if not exists mydb.dsg_portfolio.rd_nu_scoring(crn varchar,accnt_opn_date date,open_schme_code varchar,current_schme_code varchar,fkyc_date date); '
copy_query="""
COPY mydb.dsg_portfolio.rd_nu_scoring from
's3://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/rd_scoring_live/scoring.csv'
iam_role 'arn:aws:iam::718378052708:role/service-role/AmazonRedshift-CommandsAccessRole-20240513T161101'
CSV IGNOREHEADER 1"""
cursor.execute(create_query)
cursor.execute(copy_query)

con.close()

###############  amb

sql = connection.execute("""
  with pre_mnth as (
 SELECT crn,
DATEADD(month, -1, current_date) as m1,
DATEADD(month, -2, current_date) as m2,
DATEADD(month, -3, current_date) as m3,
DATEADD(month, -4, current_date) as m4,
DATEADD(month, -5, current_date) as m5,
DATEADD(month, -6, current_date) as m6,
(( extract(year from m1 ) *100 )+extract(month from  m1)) as my1,
(( extract(year from m2 ) *100 )+extract(month from  m2)) as my2,
(( extract(year from m3 ) *100 )+extract(month from  m3)) as my3,
(( extract(year from m4 ) *100 )+extract(month from  m4)) as my4,
(( extract(year from m5 ) *100 )+extract(month from  m5)) as my5,
(( extract(year from m6 ) *100 )+extract(month from  m6)) as my6

from mydb.dsg_portfolio.rd_nu_scoring 
)

select a.crn,
sum(case when mnth_year=my1 then amb else null end ) as amb_1,
sum(case when mnth_year=my2 then amb else null end ) as amb_2,
sum(case when mnth_year=my3 then amb else null end ) as amb_3,
sum(case when mnth_year=my4 then amb else null end ) as amb_4,
sum(case when mnth_year=my5 then amb else null end ) as amb_5,
sum(case when mnth_year=my6 then amb else null end ) as amb_6


from pre_mnth a 
left join dsg_portfolio.mom_amb_tall b 
on a.crn=b.crn
and prodct_type='SBA'
group by a.crn
""")
amb = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/amb/month={mnthid}/amb_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
amb.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




######### tran

sql = connection.execute("""
  with pre_mnth as (
 SELECT crn,
DATEADD(month, -1, current_date::date) as m1,
DATEADD(month, -2, current_date::date) as m2,
DATEADD(month, -3, current_date::date) as m3,
DATEADD(month, -4, current_date::date) as m4,
DATEADD(month, -5, current_date::date) as m5,
DATEADD(month, -6, current_date::date) as m6,
(( extract(year from m1 ) *100 )+extract(month from  m1)) as my1,
(( extract(year from m2 ) *100 )+extract(month from  m2)) as my2,
(( extract(year from m3 ) *100 )+extract(month from  m3)) as my3,
(( extract(year from m4 ) *100 )+extract(month from  m4)) as my4,
(( extract(year from m5 ) *100 )+extract(month from  m5)) as my5,
(( extract(year from m6 ) *100 )+extract(month from  m6)) as my6

from mydb.dsg_portfolio.rd_nu_scoring  
)
select distinct 
a.crn,
sum(case when monthid=my1 then cr_cnt else null end ) as cr_cnt_1,
sum(case when monthid=my2 then cr_cnt else null end ) as cr_cnt_2,
sum(case when monthid=my3 then cr_cnt else null end ) as cr_cnt_3,
sum(case when monthid=my4 then cr_cnt else null end ) as cr_cnt_4,
sum(case when monthid=my5 then cr_cnt else null end ) as cr_cnt_5,
sum(case when monthid=my6 then cr_cnt else null end ) as cr_cnt_6,

sum(case when monthid=my1 then cr_amt else null end ) as cr_amt_1,
sum(case when monthid=my2 then cr_amt else null end ) as cr_amt_2,
sum(case when monthid=my3 then cr_amt else null end ) as cr_amt_3,
sum(case when monthid=my4 then cr_amt else null end ) as cr_amt_4,
sum(case when monthid=my5 then cr_amt else null end ) as cr_amt_5,
sum(case when monthid=my6 then cr_amt else null end ) as cr_amt_6,

sum(case when monthid=my1 then dr_cnt else null end ) as dr_cnt_1,
sum(case when monthid=my2 then dr_cnt else null end ) as dr_cnt_2,
sum(case when monthid=my3 then dr_cnt else null end ) as dr_cnt_3,
sum(case when monthid=my4 then dr_cnt else null end ) as dr_cnt_4,
sum(case when monthid=my5 then dr_cnt else null end ) as dr_cnt_5,
sum(case when monthid=my6 then dr_cnt else null end ) as dr_cnt_6,

sum(case when monthid=my1 then dr_amt else null end ) as dr_amt_1,
sum(case when monthid=my2 then dr_amt else null end ) as dr_amt_2,
sum(case when monthid=my3 then dr_amt else null end ) as dr_amt_3,
sum(case when monthid=my4 then dr_amt else null end ) as dr_amt_4,
sum(case when monthid=my5 then dr_amt else null end ) as dr_amt_5,
sum(case when monthid=my6 then dr_amt else null end ) as dr_amt_6

from pre_mnth a 
left join dsg_portfolio.mom_tran_crdr b 
on a.crn=b.crn
group by a.crn 

""")
tran = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/crdr/month={mnthid}/crdr_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
tran.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




# ######### demogs

sql = connection.execute("""
 select distinct  a.crn, b.occupation, dob, total_rv,c.first_credit_date,c.first_credit_amt,tier_cate, primary_miss


from mydb.dsg_portfolio.rd_nu_scoring  a 
left join prod_db.dsg_portfolio.base_dashboard_811 b 
on a.crn=b.crn
left join dsg_services.funding_file_monthly c 
on a.crn=c.crn
 where report_month =(select max(report_month) from prod_db.dsg_services.funding_file_monthly)
 and month=(select max(month) from prod_db.dsg_portfolio.base_dashboard_811)
 """.format(ref_m1=ref_m1))
demogs = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/demogs/month={mnthid}/demogs_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
demogs.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)



################ mobile login


sql = connection.execute("""

     select distinct  b.crn,
    sum(case when current_date - cast(login_time as date) <=90 then 1 else 0 end ) as login_3m,
    sum(case when current_date - cast(login_time as date) >90 then 1 else 0 end ) as login_6m


    from 

    dwh_dmrt.uc5_convenience_report_details_login a
    join mydb.dsg_portfolio.rd_nu_scoring  b 
    on a.crn=b.crn
    where current_date - cast(login_time as date) <=180
    group by b.crn
""")
mb = pd.DataFrame(sql.fetch_dataframe())
#write data to s3

bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/mb/month={mnthid}/mb_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
mb.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)




######### cibil

sql = connection.execute("""
  with
      rep_mnth as (
        select
          crn,
          max(report_month) as report_month
        from
          dwh_stg.stg_ebix_cibil_data_tl
        group by
          crn
      )
    select distinct
      a.crn,
      loan_status,
      date_opened,
      date_closed,
      loan_type,
      sanction_amount
    from
      dwh_stg.stg_ebix_cibil_data_tl a
      join rep_mnth b on a.crn = b.crn
      and a.report_month = b.report_month
      join mydb.dsg_portfolio.rd_nu_scoring c on a.crn = c.crn
    where
       loan_type in ('Credit Card','Home Loan','Personal Loan','Consumer Loan')
      and current_date > date_opened
      and (
        (date_closed - current_date) > 30
        or date_closed is null
      )
""")
cibil = pd.DataFrame(sql.fetch_dataframe())
#write data to s3


bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/cibil/month={mnthid}/cibil_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
cibil.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

##### gph
sql = connection.execute("""

  with cte2 as 
(
select crn, max(as_on_date) as asondate
from mydb.dsg_portfolio.rd_nu_scoring  c
left join
 dwh_DMRT.DM_GPH_PRI_CRN PH
on c.crn=ph.prmary_crn
where ph.as_on_date<=current_date

group by crn
)
select ph.AS_ON_DATE ,PRMARY_CRN, td_stndaln_tag,dmat_tag,trdng_flag,gen_insurnc_tag,mf_final_tag,mf_lumsum_tag,mf_sip_tag,
                       mf_othrs_tag
  from cte2 c
  join dwh_DMRT.DM_GPH_PRI_CRN PH
on c.crn=PH.prmary_crn

where
c.asondate=ph.as_on_date

""")
gph = pd.DataFrame(sql.fetch_dataframe())
#write data to s3

bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/gph/month={mnthid}/gph_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
gph.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

########

###### dc
sql = connection.execute("""

  select distinct  a.crn,
case when b.cust_id is null then 0 else 1 end as "DC_flag"

from mydb.dsg_portfolio.rd_nu_scoring a 
 left join  dsg_portfolio.debit_card_issuance_811_ads b 
 on a.crn=b.cust_id 
 where issue_date<=current_date
 and virtual_card_flag='N'
 
""")
dc = pd.DataFrame(sql.fetch_dataframe())
#write data to s3

bucket = 'kotak-811-cdp-peak-write'
write_path = '811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/dc/month={mnthid}/dc_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
dc.to_csv(buffer, index=False)
buffer.seek(0)

s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

#######



scoring_base=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/rd_scoring/month={mnthid}/scoring_{mnthid}.csv'.format(mnthid=mnthid))

demogs=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/demogs/month={mnthid}/demogs_{mnthid}.csv'.format(mnthid=mnthid))

amb=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/amb/month={mnthid}/amb_{mnthid}.csv'.format(mnthid=mnthid))


tran=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/crdr/month={mnthid}/crdr_{mnthid}.csv'.format(mnthid=mnthid))

mb=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/mb/month={mnthid}/mb_{mnthid}.csv'.format(mnthid=mnthid))

cibil=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/cibil/month={mnthid}/cibil_{mnthid}.csv'.format(mnthid=mnthid))

gph=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/gph/month={mnthid}/gph_{mnthid}.csv'.format(mnthid=mnthid))
dc=pd.read_csv('s3a://kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/dc/month={mnthid}/dc_{mnthid}.csv'.format(mnthid=mnthid))


scoring_base['fkyc_date']=pd.to_datetime(scoring_base['fkyc_date'])
scoring_base['accnt_opn_date']=pd.to_datetime(scoring_base['accnt_opn_date'])


df=pd.DataFrame()


demogs['dob']=pd.to_datetime(demogs['dob'])
demogs['first_credit_date']=pd.to_datetime(demogs['first_credit_date'])

df=pd.merge(scoring_base,demogs,on='crn',how='left')


df['dob']=pd.to_datetime(df['dob'])

df['age']=((pd.Timestamp.today()-df['dob']).dt.days)/365

df['accnt_opn_date']=pd.to_datetime(df['accnt_opn_date'],format='ISO8601')
df['fkyc_date']=pd.to_datetime(df['fkyc_date'])
df['first_credit_date']=pd.to_datetime(df['first_credit_date'])


df['days_to_fkyc']=(df['fkyc_date']-df['accnt_opn_date']).dt.days


df['vintage_fkyc']=(pd.Timestamp.today()-df['fkyc_date'])/np.timedelta64(30, 'D')
df['days_to_funding']=(df['accnt_opn_date']-df['first_credit_date']).dt.days



mb['login_inc']=(mb['login_3m']-mb['login_6m'])/mb['login_6m']
mb['login_inc']=np.where(mb['login_6m']==0,mb['login_3m'],mb['login_inc'])

df['crn']=df['crn'].astype('str')
amb['crn']=amb['crn'].astype('str')

df=pd.merge(df,amb,on='crn', how='left')
tran['crn']=tran['crn'].astype('str')

df=pd.merge(df,tran,on='crn', how='left')

mb['crn']=mb['crn'].astype('str')

df=pd.merge(df,mb[['crn','login_3m','login_inc']],on='crn',how='left')



cibil_gp=cibil.groupby(['crn','loan_type']).agg({'loan_type':'count','sanction_amount':'sum'}).rename(columns={'loan_type':'count_loans'}).unstack()



cibil_gp.columns=cibil_gp.columns.to_series().str.join("_")

cibil_gp=cibil_gp.reset_index()
cibil_gp=cibil_gp.fillna(0)
cibil_gp=cibil_gp.rename(columns={'count_loans_Consumer Loan':'CD_cnt'
                         , 'count_loans_Credit Card':'CC_cnt',
       'count_loans_Home Loan':'HL_cnt', 'count_loans_Personal Loan':'PL_cnt',
       'sanction_amount_Consumer Loan':'CD_amt', 'sanction_amount_Credit Card':'CC_amt',
       'sanction_amount_Home Loan':'HL_amt', 'sanction_amount_Personal Loan':'PL_amt'
                        })
cibil_gp['crn']=cibil_gp['crn'].astype('str')

df=pd.merge(df,cibil_gp,how='left',on='crn')

dc['crn']=dc['crn'].astype('str')

df=pd.merge(df,dc,how='left',on='crn')


gph['prmary_crn']=gph['prmary_crn'].astype('str')

df=pd.merge(df,gph,left_on='crn',right_on='prmary_crn',how='left')
df['first_credit_date']=pd.to_datetime(df['first_credit_date'])


df['amb_3m']=df[['amb_1','amb_2','amb_3']].mean(axis=1)
df['amb_6m']=df[['amb_4','amb_5','amb_6']].mean(axis=1)

df['amb_3m']=df['amb_3m'].fillna(0)
df['amb_bkt']=pd.cut(df['amb_3m'],bins=[-float('inf'),0,100,1000,5000,10000,50000,float('inf')],
       labels=['1. <=0','2. 1-100','3. 101-1k','4.1k-5k','5.5k-10k','6. 10k-50k','7. >50k'])

df['cr_cnt_3m']=df[['cr_cnt_1', 'cr_cnt_2', 'cr_cnt_3']].mean(axis=1)
df['cr_cnt_6m']=df[['cr_cnt_4', 'cr_cnt_5', 'cr_cnt_6']].mean(axis=1)
df['dr_cnt_3m']=df[['dr_cnt_1', 'dr_cnt_2', 'dr_cnt_3']].mean(axis=1)
df['dr_cnt_6m']=df[['dr_cnt_4', 'dr_cnt_5', 'dr_cnt_6']].mean(axis=1)

df['cr_amt_3m']=df[['cr_amt_1', 'cr_amt_2', 'cr_amt_3']].mean(axis=1)
df['cr_amt_6m']=df[['cr_amt_4', 'cr_amt_5', 'cr_amt_6']].mean(axis=1)
df['dr_amt_3m']=df[['dr_amt_1', 'dr_amt_2', 'dr_amt_3']].mean(axis=1)
df['dr_amt_6m']=df[['dr_amt_4', 'dr_amt_5', 'dr_amt_6']].mean(axis=1)

df['cr_cnt_diff']=df['cr_cnt_3m']-df['cr_cnt_6m']
df['cr_amt_diff']=df['cr_amt_3m']-df['cr_amt_6m']
df['dr_cnt_diff']=df['dr_cnt_3m']-df['dr_cnt_6m']
df['dr_amt_diff']=df['dr_amt_3m']-df['dr_amt_6m']

df['cr_dr_amt_diff_3m']=df['cr_amt_3m']-df['dr_amt_3m']
df['cr_dr_amt_diff_1m']=df['cr_amt_1']=df['dr_amt_1']

df['cr_cnt_inc_ratio']=(df['cr_cnt_3m']-df['cr_cnt_6m'])/df['cr_cnt_6m']
df['cr_amt_inc_ratio']=(df['cr_amt_3m']-df['cr_amt_6m'])/df['cr_amt_6m']
df['dr_cnt_inc_ratio']=(df['dr_cnt_3m']-df['dr_cnt_6m'])/df['dr_cnt_6m']
df['dr_amt_inc_ratio']=(df['dr_amt_3m']-df['dr_amt_6m'])/df['dr_amt_6m']


df['dr_cr_amt_ratio']=df['dr_amt_3m']/df['cr_amt_3m']
df['dr_cr_ats_ratio']=(df['dr_amt_3m']/df['dr_cnt_3m'])/(df['cr_amt_3m']/df['cr_cnt_3m'])
df['dr_cr_amt_ratio']=df['dr_cr_amt_ratio'].fillna(0)
df['dr_cr_ats_ratio']=df['dr_cr_ats_ratio'].fillna(0)
df['dr_cr_amt_ratio']=np.where(df['dr_cr_amt_ratio']==float('inf'),df['dr_amt_3m'],df['dr_cr_amt_ratio'])


df['dr_cr_cnt_ratio']=df['dr_cnt_3m']/df['cr_cnt_3m']
df['dr_cr_amt_ratio']=df['dr_amt_3m']/df['cr_amt_3m']


df['amb_1_3_mnth']=df.apply(lambda x : x['amb_1']/x['amb_3'] if x['amb_3']!=0 else 0, axis=1)
df['amb_1_3_mnth']=np.where(df['amb_1_3_mnth']==float('inf'),df['amb_1'],df['amb_1_3_mnth'])
df['amb_1_3_mnth']=df['amb_1_3_mnth'].fillna(0)

df['amb_3_6_diff']=df.apply(lambda x : (x['amb_3m']-x['amb_6m'])/x['amb_6m'] if x['amb_6m']!=0 else x['amb_3m'], axis=1)
df['amb_3_6_diff']=np.where(df['amb_3_6_diff']==float('inf'),df['amb_3m'],df['amb_3_6_diff'])
df['amb_3_6_diff']=df['amb_3_6_diff'].fillna(0)


df['dr_cr_amt_ratio']=df['dr_amt_3m']/df['cr_amt_3m']
df['dr_cr_ats_ratio']=(df['dr_amt_3m']/df['dr_cnt_3m'])/(df['cr_amt_3m']/df['cr_cnt_3m'])
df['dr_cr_amt_ratio']=df['dr_cr_amt_ratio'].fillna(0)
df['dr_cr_ats_ratio']=df['dr_cr_ats_ratio'].fillna(0)
df['dr_cr_amt_ratio']=np.where(df['dr_cr_amt_ratio']==float('inf'),df['dr_amt_3m'],df['dr_cr_amt_ratio'])



df['days_to_fkyc']=(df['fkyc_date']-df['accnt_opn_date']).dt.days
df['days_to_funding']=(df['first_credit_date']-df['accnt_opn_date']).dt.days
df['primary_miss']=np.where(df['primary_miss']=='PRIMARY',1,0)


df['amb_3m'].describe(percentiles=[.1,.2,.3,.4,.5,.6,.7,.8,.9])

df['occupation']=df['occupation'].replace({'Service - Private Sector':'Salaried',
    'Professional':'Salaried','Service - Public Sector':'Salaried',
    'Service - Government Sector':'Salaried','Self Employees Professional (SEP)':'Self Employed',
     'SENP - Job Worker':'Self Employed', 
       'Self Employees Professional (SEP)':'Self Employed', 'SENP - Retail Trader':'Self Employed',
       'SENP - Others':'Self Employed', 'SENP - Wholesale Trader':'Self Employed',
       'SENP - Service Industry':'Self Employed', 'Self Employed Non Professional':'Self Employed',
       'SENP - Distributor':'Self Employed', 'SENP - Manufacturer':'Self Employed','Business':  'Self Employed',
                                    'Non Working':'Others'                
    })

df['occupation']=df['occupation'].fillna('Others')


# removed 6m variables because of collinearity
# remove total rv
#removing date variables, accnt_num
base=df[['crn',   
       'occupation', 
       'first_credit_amt', 'tier_cate', 
#          'primary_miss', 'days_to_funding',
         'age', 'days_to_fkyc',
       'vintage_fkyc', 'login_3m', 'login_inc', 'CD_cnt', 'CC_cnt',
       'HL_cnt', 'PL_cnt', 'CD_amt', 'CC_amt', 'HL_amt', 'PL_amt', 'dc_flag',
        'td_stndaln_tag', 'dmat_tag', 'trdng_flag',
       'gen_insurnc_tag', 'mf_final_tag', 'mf_lumsum_tag', 'mf_sip_tag',
       'mf_othrs_tag', 'amb_3m', 'amb_6m', 'amb_bkt', 'cr_cnt_3m', 'cr_cnt_6m',
       'dr_cnt_3m', 'dr_cnt_6m', 'cr_amt_3m', 'cr_amt_6m', 'dr_amt_3m',
       'dr_amt_6m', 'cr_cnt_diff', 'cr_amt_diff', 'dr_cnt_diff', 'dr_amt_diff',
       'cr_cnt_inc_ratio', 'cr_amt_inc_ratio', 'dr_cnt_inc_ratio',
       'dr_amt_inc_ratio', 'amb_1_3_mnth', 'amb_3_6_diff', 'dr_cr_amt_ratio',
       'dr_cr_ats_ratio', 'dr_cr_cnt_ratio', 'cr_dr_amt_diff_3m',
       'cr_dr_amt_diff_1m']]

for i in [ 'first_credit_amt',  'age', 
       'login_3m', 'login_inc', 'CD_cnt', 'CC_cnt',
       'HL_cnt', 'PL_cnt', 'CD_amt', 'CC_amt', 'HL_amt', 'PL_amt', 'dc_flag',
        'td_stndaln_tag', 'dmat_tag', 'trdng_flag',
       'gen_insurnc_tag', 'mf_final_tag', 'mf_lumsum_tag', 'mf_sip_tag',
       'mf_othrs_tag', 'amb_3m', 'amb_6m',  'cr_cnt_3m', 'cr_cnt_6m',
       'dr_cnt_3m', 'dr_cnt_6m', 'cr_amt_3m', 'cr_amt_6m', 'dr_amt_3m',
       'dr_amt_6m', 'cr_cnt_diff', 'cr_amt_diff', 'dr_cnt_diff', 'dr_amt_diff',
       'cr_cnt_inc_ratio', 'cr_amt_inc_ratio', 'dr_cnt_inc_ratio',
       'dr_amt_inc_ratio', 'amb_1_3_mnth', 'amb_3_6_diff', 'dr_cr_amt_ratio',
       'dr_cr_ats_ratio', 'dr_cr_cnt_ratio', 'cr_dr_amt_diff_3m',
       'cr_dr_amt_diff_1m']:
    print(i)
    base[i]=base[i].fillna(0)





base[base['days_to_fkyc'].isna()].shape

# base['days_to_funding']=base['days_to_funding'].fillna(9999)
base=base.dropna(subset=['days_to_fkyc'],axis='index')

(base.isna().sum()/base.shape[0])*100




def one_hot(df, cols,drop_og_variable=False):
    """
    df:pandas DataFrame
    cols: a list of columns to encode 
    return a DataFrame with one-hot encoding
    """
    for each in cols:
        dummies = pd.get_dummies(df[each], prefix=each, drop_first=drop_og_variable)
        dummies.replace({True:'1',False:'0'},inplace=True)
        df = pd.concat([df, dummies], axis=1)
    df.drop(cols,axis=1,inplace=True)
    return df

cols=['occupation','amb_bkt','tier_cate']
base=one_hot(base,cols,True)



#### get model file

model_path="811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/model_files/"
bucket_name='kotak-811-cdp-peak-write'


with tempfile.TemporaryFile() as fp:
    s3.download_fileobj(Fileobj=fp, Bucket=bucket_name, Key=model_path+"rf_model_balanced_15maxdep_100trees_2varremoved.pkl")
    fp.seek(0)
    rf_model = joblib.load(fp)

base=base.drop_duplicates('crn')


x=base[['first_credit_amt', 'age', 'days_to_fkyc', 'vintage_fkyc', 'login_3m',
       'login_inc', 'CD_cnt', 'CC_cnt', 'HL_cnt', 'PL_cnt', 'CD_amt', 'CC_amt',
       'HL_amt', 'PL_amt', 'dc_flag', 'td_stndaln_tag', 'dmat_tag',
       'trdng_flag', 'gen_insurnc_tag', 'mf_final_tag', 'mf_lumsum_tag',
       'mf_sip_tag', 'mf_othrs_tag', 'amb_3m', 'amb_6m', 'cr_cnt_3m',
       'cr_cnt_6m', 'dr_cnt_3m', 'dr_cnt_6m', 'cr_amt_3m', 'cr_amt_6m',
       'dr_amt_3m', 'dr_amt_6m', 'cr_cnt_diff', 'cr_amt_diff', 'dr_cnt_diff',
       'dr_amt_diff', 'cr_cnt_inc_ratio', 'cr_amt_inc_ratio',
       'dr_cnt_inc_ratio', 'dr_amt_inc_ratio', 'amb_1_3_mnth', 'amb_3_6_diff',
       'dr_cr_amt_ratio', 'dr_cr_ats_ratio', 'dr_cr_cnt_ratio',
       'cr_dr_amt_diff_3m', 'cr_dr_amt_diff_1m',
       'occupation_House Wife or Home Maker', 'occupation_Others',
       'occupation_Retired', 'occupation_Salaried', 'occupation_Self Employed',
       'occupation_Student', 'amb_bkt_2. 1-100', 'amb_bkt_3. 101-1k',
       'amb_bkt_4.1k-5k', 'amb_bkt_5.5k-10k', 'amb_bkt_6. 10k-50k',
       'amb_bkt_7. >50k', 'tier_cate_b) Tier_2', 'tier_cate_c) Tier_3']]

pred=rf_model.predict(x)


base['pred']=pred

base['pred_proba']=rf_model.predict_proba(x)[:,1]


base['decile']=10-pd.qcut(base['pred_proba'], 10, labels = False)

gp_total=base.groupby(['decile']).agg({'pred_proba':['count','max','min']}).reset_index()

final_base=base[['crn','pred_proba','decile']]

bucket = 'kotak-811-cdp-peak-write'
write_path = 'kotak-811-cdp-peak-write/811-cdp-peak-main/datascience/td/td_monthly_campaigns/rd_nu/full_base/month={mnthid}/rd_nu_base_{mnthid}.csv'.format(mnthid=mnthid)

buffer = io.BytesIO()
final_base.to_csv(buffer, index=False)
buffer.seek(0)
s3.put_object(Body=buffer, Bucket=bucket, Key=write_path)

